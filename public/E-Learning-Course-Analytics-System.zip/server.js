// server.ts
import express2 from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

// backend/src/app.ts
import express from "express";

// backend/src/routes/api.ts
import { Router } from "express";

// backend/src/repositories/db.ts
import { DatabaseSync } from "node:sqlite";

// backend/src/repositories/modulesData.ts
var initialCourseModules = [
  // -------------------------------------------------------------------
  // 1. crs-101: Modern Full-Stack Web Development (Computer Science)
  // -------------------------------------------------------------------
  {
    module_id: "mod-101-1",
    course_id: "crs-101",
    module_name: "Module 1: HTML5, Semantic Markup & CSS3 Layout Architecture",
    description: "Foundations of web document structuring, semantic accessibility, Flexbox, and CSS Grid.",
    sequence_no: 1,
    created_at: "2026-08-01 09:10:00",
    updated_at: "2026-08-01 09:10:00"
  },
  {
    module_id: "mod-101-2",
    course_id: "crs-101",
    module_name: "Module 2: JavaScript ES6+ & TypeScript Type Systems",
    description: "Modern asynchronous JavaScript, closures, promises, TypeScript static typing, and interfaces.",
    sequence_no: 2,
    created_at: "2026-08-01 09:20:00",
    updated_at: "2026-08-01 09:20:00"
  },
  {
    module_id: "mod-101-3",
    course_id: "crs-101",
    module_name: "Module 3: React Architecture, Component Trees & Custom Hooks",
    description: "Declarative component design, state encapsulation, effect lifecycles, and custom hook composition.",
    sequence_no: 3,
    created_at: "2026-08-01 09:30:00",
    updated_at: "2026-08-01 09:30:00"
  },
  {
    module_id: "mod-101-4",
    course_id: "crs-101",
    module_name: "Module 4: Node.js, Express & Enterprise RESTful APIs",
    description: "Server runtime internals, middleware pipelines, authentication tokens, and API error routing.",
    sequence_no: 4,
    created_at: "2026-08-01 09:40:00",
    updated_at: "2026-08-01 09:40:00"
  },
  {
    module_id: "mod-101-5",
    course_id: "crs-101",
    module_name: "Module 5: Full-Stack Integration, SQL Persistence & Cloud Deployment",
    description: "End-to-end client-server wiring, relational database modeling, containerization, and production deployment.",
    sequence_no: 5,
    created_at: "2026-08-01 09:50:00",
    updated_at: "2026-08-01 09:50:00"
  },
  // -------------------------------------------------------------------
  // 2. crs-102: Practical Data Science & Machine Learning (Data & AI)
  // -------------------------------------------------------------------
  {
    module_id: "mod-102-1",
    course_id: "crs-102",
    module_name: "Module 1: Python for Scientific Computing & Matrix Operations",
    description: "NumPy vectorized arrays, multidimensional broadcasting, and mathematical operations for data analysis.",
    sequence_no: 1,
    created_at: "2026-08-05 10:40:00",
    updated_at: "2026-08-05 10:40:00"
  },
  {
    module_id: "mod-102-2",
    course_id: "crs-102",
    module_name: "Module 2: Data Wrangling, Cleaning & Exploration with Pandas",
    description: "DataFrame manipulations, imputation of missing data, outlier detection, and exploratory visualization.",
    sequence_no: 2,
    created_at: "2026-08-05 10:50:00",
    updated_at: "2026-08-05 10:50:00"
  },
  {
    module_id: "mod-102-3",
    course_id: "crs-102",
    module_name: "Module 3: Statistical Inference, Probability Distributions & Hypothesis Testing",
    description: "Parametric and non-parametric tests, p-value interpretation, confidence intervals, and ANOVA.",
    sequence_no: 3,
    created_at: "2026-08-05 11:00:00",
    updated_at: "2026-08-05 11:00:00"
  },
  {
    module_id: "mod-102-4",
    course_id: "crs-102",
    module_name: "Module 4: Supervised & Unsupervised Machine Learning with Scikit-Learn",
    description: "Linear regressions, classification trees, random forests, clustering algorithms, and hyperparameter tuning.",
    sequence_no: 4,
    created_at: "2026-08-05 11:10:00",
    updated_at: "2026-08-05 11:10:00"
  },
  {
    module_id: "mod-102-5",
    course_id: "crs-102",
    module_name: "Module 5: Deep Neural Networks & Production Model Serving",
    description: "Backpropagation, PyTorch tensors, model evaluation metrics (ROC-AUC, F1), and model serialization.",
    sequence_no: 5,
    created_at: "2026-08-05 11:20:00",
    updated_at: "2026-08-05 11:20:00"
  },
  // -------------------------------------------------------------------
  // 3. crs-103: Cloud Infrastructure & DevOps Mastery (Cloud Architecture)
  // -------------------------------------------------------------------
  {
    module_id: "mod-103-1",
    course_id: "crs-103",
    module_name: "Module 1: Linux System Administration & Shell Automation",
    description: "UNIX filesystem hierarchy, permissions, systemd services, SSH keys, and automated bash scripting.",
    sequence_no: 1,
    created_at: "2026-08-10 11:25:00",
    updated_at: "2026-08-10 11:25:00"
  },
  {
    module_id: "mod-103-2",
    course_id: "crs-103",
    module_name: "Module 2: Containerization with Docker & Multi-Stage Image Builds",
    description: "Namespaces, cgroups, image layering, Docker compose networking, and container image hardening.",
    sequence_no: 2,
    created_at: "2026-08-10 11:35:00",
    updated_at: "2026-08-10 11:35:00"
  },
  {
    module_id: "mod-103-3",
    course_id: "crs-103",
    module_name: "Module 3: Continuous Integration & Automated Release Pipelines",
    description: "GitHub Actions and GitLab CI, automated unit/integration testing gates, linting, and artifact publishing.",
    sequence_no: 3,
    created_at: "2026-08-10 11:45:00",
    updated_at: "2026-08-10 11:45:00"
  },
  {
    module_id: "mod-103-4",
    course_id: "crs-103",
    module_name: "Module 4: Kubernetes Cluster Orchestration, Deployments & Networking",
    description: "Kubernetes control plane, pods, services, ingress controllers, ConfigMaps, and rolling upgrades.",
    sequence_no: 4,
    created_at: "2026-08-10 11:55:00",
    updated_at: "2026-08-10 11:55:00"
  },
  {
    module_id: "mod-103-5",
    course_id: "crs-103",
    module_name: "Module 5: Infrastructure as Code (Terraform) & Cloud Observability",
    description: "Terraform declarative state management, cloud provisioning, Prometheus metrics, and Grafana dashboards.",
    sequence_no: 5,
    created_at: "2026-08-10 12:05:00",
    updated_at: "2026-08-10 12:05:00"
  },
  // -------------------------------------------------------------------
  // 4. crs-104: Applied Cybersecurity & Threat Defense (Information Security)
  // -------------------------------------------------------------------
  {
    module_id: "mod-104-1",
    course_id: "crs-104",
    module_name: "Module 1: Computer Networking Fundamentals & Packet Analysis",
    description: "OSI 7-layer model, TCP/IP handshakes, packet capture with Wireshark, DNS, and subnetting.",
    sequence_no: 1,
    created_at: "2026-08-15 14:10:00",
    updated_at: "2026-08-15 14:10:00"
  },
  {
    module_id: "mod-104-2",
    course_id: "crs-104",
    module_name: "Module 2: Threat Modeling, Reconnaissance & Vulnerability Scanning",
    description: "OSINT gathering, Nmap port scanning, banner grabbing, CVE auditing, and STRIDE threat modeling.",
    sequence_no: 2,
    created_at: "2026-08-15 14:20:00",
    updated_at: "2026-08-15 14:20:00"
  },
  {
    module_id: "mod-104-3",
    course_id: "crs-104",
    module_name: "Module 3: Web Application Security & OWASP Top 10 Exploitation & Defense",
    description: "SQL Injection, Cross-Site Scripting (XSS), CSRF, insecure direct object references, and secure coding.",
    sequence_no: 3,
    created_at: "2026-08-15 14:30:00",
    updated_at: "2026-08-15 14:30:00"
  },
  {
    module_id: "mod-104-4",
    course_id: "crs-104",
    module_name: "Module 4: Cryptography Principles, PKI & Secure Communications",
    description: "Symmetric vs asymmetric ciphers (AES, RSA), hashing algorithms (SHA-256), PKI certificates, and TLS.",
    sequence_no: 4,
    created_at: "2026-08-15 14:40:00",
    updated_at: "2026-08-15 14:40:00"
  },
  {
    module_id: "mod-104-5",
    course_id: "crs-104",
    module_name: "Module 5: Incident Response, Digital Forensics & Threat Hunting",
    description: "SANS/NIST incident response lifecycles, memory forensics, SIEM telemetry analysis, and threat containment.",
    sequence_no: 5,
    created_at: "2026-08-15 14:50:00",
    updated_at: "2026-08-15 14:50:00"
  },
  // -------------------------------------------------------------------
  // 5. crs-105: Enterprise UI/UX Design Systems (Design & Product)
  // -------------------------------------------------------------------
  {
    module_id: "mod-105-1",
    course_id: "crs-105",
    module_name: "Module 1: Foundations of User Experience (UX) & Design Thinking",
    description: "User-centered design principles, empathy mapping, user interview synthesis, and persona development.",
    sequence_no: 1,
    created_at: "2026-08-20 16:30:00",
    updated_at: "2026-08-20 16:30:00"
  },
  {
    module_id: "mod-105-2",
    course_id: "crs-105",
    module_name: "Module 2: Information Architecture, User Flows & Wireframing",
    description: "Site mapping, task flows, low-fidelity wireframing in Figma, and early usability validation.",
    sequence_no: 2,
    created_at: "2026-08-20 16:40:00",
    updated_at: "2026-08-20 16:40:00"
  },
  {
    module_id: "mod-105-3",
    course_id: "crs-105",
    module_name: "Module 3: Visual Hierarchy, Typography, Color & Atomic Layouts",
    description: "Type scales, contrast ratios, grid systems, spatial rhythm, and atomic design methodology.",
    sequence_no: 3,
    created_at: "2026-08-20 16:50:00",
    updated_at: "2026-08-20 16:50:00"
  },
  {
    module_id: "mod-105-4",
    course_id: "crs-105",
    module_name: "Module 4: Scalable Design Systems in Figma & Component Tokens",
    description: "Master component variants, auto-layout, semantic design tokens, and multi-brand style libraries.",
    sequence_no: 4,
    created_at: "2026-08-20 17:00:00",
    updated_at: "2026-08-20 17:00:00"
  },
  {
    module_id: "mod-105-5",
    course_id: "crs-105",
    module_name: "Module 5: Web Accessibility (WCAG 2.2), Usability Testing & Dev Handoff",
    description: "WCAG 2.2 AA compliance standards, screen-reader testing, usability testing protocols, and design-dev handoff.",
    sequence_no: 5,
    created_at: "2026-08-20 17:10:00",
    updated_at: "2026-08-20 17:10:00"
  },
  // -------------------------------------------------------------------
  // 6. crs-106: Special Topics Seminar (Elective Only) (General Studies)
  // -------------------------------------------------------------------
  {
    module_id: "mod-106-1",
    course_id: "crs-106",
    module_name: "Module 1: Academic Research Methodologies & Critical Thinking",
    description: "Scientific method, peer-reviewed literature navigation, identifying cognitive biases, and research synthesis.",
    sequence_no: 1,
    created_at: "2026-09-01 08:10:00",
    updated_at: "2026-09-01 08:10:00"
  },
  {
    module_id: "mod-106-2",
    course_id: "crs-106",
    module_name: "Module 2: Technical Communication & High-Impact Presentations",
    description: "Structure of scientific writing, slide design for complex ideas, and rhetorical delivery techniques.",
    sequence_no: 2,
    created_at: "2026-09-01 08:20:00",
    updated_at: "2026-09-01 08:20:00"
  },
  {
    module_id: "mod-106-3",
    course_id: "crs-106",
    module_name: "Module 3: Ethics in Artificial Intelligence & Emerging Technologies",
    description: "Algorithmic bias, automated decision accountability, data privacy, and ethical frameworks for AI.",
    sequence_no: 3,
    created_at: "2026-09-01 08:30:00",
    updated_at: "2026-09-01 08:30:00"
  },
  {
    module_id: "mod-106-4",
    course_id: "crs-106",
    module_name: "Module 4: Open-Source Governance, Collaboration & Intellectual Property",
    description: "Software licenses (GPL, Apache, MIT), open-source community dynamics, and collaborative Git practices.",
    sequence_no: 4,
    created_at: "2026-09-01 08:40:00",
    updated_at: "2026-09-01 08:40:00"
  },
  {
    module_id: "mod-106-5",
    course_id: "crs-106",
    module_name: "Module 5: Peer Review Seminar, Thesis Critique & Capstone Defense",
    description: "Conducting constructive peer reviews, defending technical theses, and scientific reproducibility standards.",
    sequence_no: 5,
    created_at: "2026-09-01 08:50:00",
    updated_at: "2026-09-01 08:50:00"
  },
  // -------------------------------------------------------------------
  // 7. crs-107: Upcoming Quantum Computing Primer (Advanced Science)
  // -------------------------------------------------------------------
  {
    module_id: "mod-107-1",
    course_id: "crs-107",
    module_name: "Module 1: Linear Algebra & Hilbert Spaces for Quantum Mechanics",
    description: "Complex vector spaces, Dirac notation, matrix inner products, Hermitian operators, and spectral theorem.",
    sequence_no: 1,
    created_at: "2026-09-10 12:10:00",
    updated_at: "2026-09-10 12:10:00"
  },
  {
    module_id: "mod-107-2",
    course_id: "crs-107",
    module_name: "Module 2: Qubits, Quantum Superposition & Entanglement Principles",
    description: "Pure state representations on the Bloch sphere, measurement postulates, quantum entanglement, and Bell inequalities.",
    sequence_no: 2,
    created_at: "2026-09-10 12:20:00",
    updated_at: "2026-09-10 12:20:00"
  },
  {
    module_id: "mod-107-3",
    course_id: "crs-107",
    module_name: "Module 3: Quantum Logic Gates & Quantum Circuit Construction",
    description: "Unitary transformations, Pauli gates, Hadamard transformation, controlled gates (CNOT, Toffoli), and circuit design.",
    sequence_no: 3,
    created_at: "2026-09-10 12:30:00",
    updated_at: "2026-09-10 12:30:00"
  },
  {
    module_id: "mod-107-4",
    course_id: "crs-107",
    module_name: "Module 4: Foundational Quantum Algorithms (Deutsch-Jozsa, Grover & Shor)",
    description: "Quantum speedup principles, phase kickback, oracle evaluation, Grover amplitude amplification, and Shor period-finding.",
    sequence_no: 4,
    created_at: "2026-09-10 12:40:00",
    updated_at: "2026-09-10 12:40:00"
  },
  {
    module_id: "mod-107-5",
    course_id: "crs-107",
    module_name: "Module 5: Quantum Programming with Qiskit & Physical Quantum Hardware",
    description: "Hands-on circuit simulation in Python Qiskit, executing on cloud IBM Quantum QPUs, and NISQ-era noise mitigation.",
    sequence_no: 5,
    created_at: "2026-09-10 12:50:00",
    updated_at: "2026-09-10 12:50:00"
  }
];
var initialModuleVideos = [
  // ===================================================================
  // COURSE 1: crs-101 (Modern Full-Stack Web Development)
  // ===================================================================
  // Module 101-1
  {
    video_id: "vid-101-1-1",
    module_id: "mod-101-1",
    course_id: "crs-101",
    title: "HTML & CSS Full Course - Beginner to Pro",
    youtube_video_id: "mU6anWqZJcc",
    youtube_url: "https://www.youtube.com/watch?v=mU6anWqZJcc",
    embed_url: "https://www.youtube-nocookie.com/embed/mU6anWqZJcc",
    thumbnail_url: "https://img.youtube.com/vi/mU6anWqZJcc/hqdefault.jpg",
    duration: "11:43:00",
    duration_seconds: 42180,
    channel_name: "freeCodeCamp.org",
    description: "Complete hands-on masterclass covering HTML5 tags, document structure, modern styling, and semantic page flow.",
    sequence_no: 1,
    created_at: "2026-08-01 09:12:00",
    updated_at: "2026-08-01 09:12:00"
  },
  {
    video_id: "vid-101-1-2",
    module_id: "mod-101-1",
    course_id: "crs-101",
    title: "Flexbox vs CSS Grid - How to Choose the Right Tool",
    youtube_video_id: "JJSoEo8JSnc",
    youtube_url: "https://www.youtube.com/watch?v=JJSoEo8JSnc",
    embed_url: "https://www.youtube-nocookie.com/embed/JJSoEo8JSnc",
    thumbnail_url: "https://img.youtube.com/vi/JJSoEo8JSnc/hqdefault.jpg",
    duration: "22:45",
    duration_seconds: 1365,
    channel_name: "Kevin Powell",
    description: "In-depth breakdown of one-dimensional Flexbox layout versus two-dimensional CSS Grid architecture.",
    sequence_no: 2,
    created_at: "2026-08-01 09:14:00",
    updated_at: "2026-08-01 09:14:00"
  },
  {
    video_id: "vid-101-1-3",
    module_id: "mod-101-1",
    course_id: "crs-101",
    title: "Responsive Web Design Essentials & Media Queries",
    youtube_video_id: "srvUrASNj0s",
    youtube_url: "https://www.youtube.com/watch?v=srvUrASNj0s",
    embed_url: "https://www.youtube-nocookie.com/embed/srvUrASNj0s",
    thumbnail_url: "https://img.youtube.com/vi/srvUrASNj0s/hqdefault.jpg",
    duration: "15:30",
    duration_seconds: 930,
    channel_name: "Web Dev Simplified",
    description: "Master mobile-first responsive layouts, viewport meta tags, break point strategy, and fluid typography.",
    sequence_no: 3,
    created_at: "2026-08-01 09:16:00",
    updated_at: "2026-08-01 09:16:00"
  },
  // Module 101-2
  {
    video_id: "vid-101-2-1",
    module_id: "mod-101-2",
    course_id: "crs-101",
    title: "JavaScript Programming Tutorial for Beginners",
    youtube_video_id: "W6NZfCO5SIk",
    youtube_url: "https://www.youtube.com/watch?v=W6NZfCO5SIk",
    embed_url: "https://www.youtube-nocookie.com/embed/W6NZfCO5SIk",
    thumbnail_url: "https://img.youtube.com/vi/W6NZfCO5SIk/hqdefault.jpg",
    duration: "01:40:20",
    duration_seconds: 6020,
    channel_name: "Programming with Mosh",
    description: "Core JavaScript fundamentals: variables, arrays, objects, functions, loops, and DOM manipulation basics.",
    sequence_no: 1,
    created_at: "2026-08-01 09:22:00",
    updated_at: "2026-08-01 09:22:00"
  },
  {
    video_id: "vid-101-2-2",
    module_id: "mod-101-2",
    course_id: "crs-101",
    title: "TypeScript Full Course for Beginners",
    youtube_video_id: "d56mG7DezGs",
    youtube_url: "https://www.youtube.com/watch?v=d56mG7DezGs",
    embed_url: "https://www.youtube-nocookie.com/embed/d56mG7DezGs",
    thumbnail_url: "https://img.youtube.com/vi/d56mG7DezGs/hqdefault.jpg",
    duration: "02:40:12",
    duration_seconds: 9612,
    channel_name: "The Net Ninja",
    description: "Learn TypeScript from scratch: types, interfaces, classes, generics, modules, and compiler configuration.",
    sequence_no: 2,
    created_at: "2026-08-01 09:24:00",
    updated_at: "2026-08-01 09:24:00"
  },
  {
    video_id: "vid-101-2-3",
    module_id: "mod-101-2",
    course_id: "crs-101",
    title: "Modern TypeScript in 100 Seconds",
    youtube_video_id: "zQnBQ4tB3ZA",
    youtube_url: "https://www.youtube.com/watch?v=zQnBQ4tB3ZA",
    embed_url: "https://www.youtube-nocookie.com/embed/zQnBQ4tB3ZA",
    thumbnail_url: "https://img.youtube.com/vi/zQnBQ4tB3ZA/hqdefault.jpg",
    duration: "02:18",
    duration_seconds: 138,
    channel_name: "Fireship",
    description: "Rapid-fire summary of TypeScript syntax, structural typing, type inference, and tooling benefits.",
    sequence_no: 3,
    created_at: "2026-08-01 09:26:00",
    updated_at: "2026-08-01 09:26:00"
  },
  // Module 101-3
  {
    video_id: "vid-101-3-1",
    module_id: "mod-101-3",
    course_id: "crs-101",
    title: "React Crash Course for Modern Web Development",
    youtube_video_id: "w7ejDZ8SWv8",
    youtube_url: "https://www.youtube.com/watch?v=w7ejDZ8SWv8",
    embed_url: "https://www.youtube-nocookie.com/embed/w7ejDZ8SWv8",
    thumbnail_url: "https://img.youtube.com/vi/w7ejDZ8SWv8/hqdefault.jpg",
    duration: "01:58:30",
    duration_seconds: 7110,
    channel_name: "Traversy Media",
    description: "Building interactive SPAs with React, JSX syntax, component props, and event handlers.",
    sequence_no: 1,
    created_at: "2026-08-01 09:32:00",
    updated_at: "2026-08-01 09:32:00"
  },
  {
    video_id: "vid-101-3-2",
    module_id: "mod-101-3",
    course_id: "crs-101",
    title: "React Hooks Explained: useState, useEffect & Custom Hooks",
    youtube_video_id: "TNhaISOUy6Q",
    youtube_url: "https://www.youtube.com/watch?v=TNhaISOUy6Q",
    embed_url: "https://www.youtube-nocookie.com/embed/TNhaISOUy6Q",
    thumbnail_url: "https://img.youtube.com/vi/TNhaISOUy6Q/hqdefault.jpg",
    duration: "24:15",
    duration_seconds: 1455,
    channel_name: "Web Dev Simplified",
    description: "Comprehensive guide to functional state management, side effects, dependency arrays, and custom hook logic.",
    sequence_no: 2,
    created_at: "2026-08-01 09:34:00",
    updated_at: "2026-08-01 09:34:00"
  },
  {
    video_id: "vid-101-3-3",
    module_id: "mod-101-3",
    course_id: "crs-101",
    title: "React Component Architecture & State Management Patterns",
    youtube_video_id: "35lXWvCuM8o",
    youtube_url: "https://www.youtube.com/watch?v=35lXWvCuM8o",
    embed_url: "https://www.youtube-nocookie.com/embed/35lXWvCuM8o",
    thumbnail_url: "https://img.youtube.com/vi/35lXWvCuM8o/hqdefault.jpg",
    duration: "32:10",
    duration_seconds: 1930,
    channel_name: "freeCodeCamp.org",
    description: "Architecting scalable frontend component trees, context providers, and memoization techniques.",
    sequence_no: 3,
    created_at: "2026-08-01 09:36:00",
    updated_at: "2026-08-01 09:36:00"
  },
  // Module 101-4
  {
    video_id: "vid-101-4-1",
    module_id: "mod-101-4",
    course_id: "crs-101",
    title: "Node.js and Express.js Full Course",
    youtube_video_id: "Oe421EPjeBE",
    youtube_url: "https://www.youtube.com/watch?v=Oe421EPjeBE",
    embed_url: "https://www.youtube-nocookie.com/embed/Oe421EPjeBE",
    thumbnail_url: "https://img.youtube.com/vi/Oe421EPjeBE/hqdefault.jpg",
    duration: "08:15:40",
    duration_seconds: 29740,
    channel_name: "freeCodeCamp.org",
    description: "Deep dive into server-side JavaScript, file system APIs, Express routing, and middleware pipelines.",
    sequence_no: 1,
    created_at: "2026-08-01 09:42:00",
    updated_at: "2026-08-01 09:42:00"
  },
  {
    video_id: "vid-101-4-2",
    module_id: "mod-101-4",
    course_id: "crs-101",
    title: "Building Secure RESTful APIs with Express & JWT",
    youtube_video_id: "mbsmsi7l3r4",
    youtube_url: "https://www.youtube.com/watch?v=mbsmsi7l3r4",
    embed_url: "https://www.youtube-nocookie.com/embed/mbsmsi7l3r4",
    thumbnail_url: "https://img.youtube.com/vi/mbsmsi7l3r4/hqdefault.jpg",
    duration: "48:20",
    duration_seconds: 2900,
    channel_name: "Web Dev Simplified",
    description: "Securing API endpoints using JSON Web Tokens (JWT), password hashing with bcrypt, and role guards.",
    sequence_no: 2,
    created_at: "2026-08-01 09:44:00",
    updated_at: "2026-08-01 09:44:00"
  },
  {
    video_id: "vid-101-4-3",
    module_id: "mod-101-4",
    course_id: "crs-101",
    title: "What the heck is the event loop anyway?",
    youtube_video_id: "8aGhZQkoFbQ",
    youtube_url: "https://www.youtube.com/watch?v=8aGhZQkoFbQ",
    embed_url: "https://www.youtube-nocookie.com/embed/8aGhZQkoFbQ",
    thumbnail_url: "https://img.youtube.com/vi/8aGhZQkoFbQ/hqdefault.jpg",
    duration: "26:50",
    duration_seconds: 1610,
    channel_name: "JSConf / Philip Roberts",
    description: "The seminal computer science presentation explaining the V8 engine, call stack, task queue, and event loop.",
    sequence_no: 3,
    created_at: "2026-08-01 09:46:00",
    updated_at: "2026-08-01 09:46:00"
  },
  // Module 101-5
  {
    video_id: "vid-101-5-1",
    module_id: "mod-101-5",
    course_id: "crs-101",
    title: "Full Stack Web Development for Beginners",
    youtube_video_id: "nu_pCVPKzTk",
    youtube_url: "https://www.youtube.com/watch?v=nu_pCVPKzTk",
    embed_url: "https://www.youtube-nocookie.com/embed/nu_pCVPKzTk",
    thumbnail_url: "https://img.youtube.com/vi/nu_pCVPKzTk/hqdefault.jpg",
    duration: "07:18:20",
    duration_seconds: 26300,
    channel_name: "freeCodeCamp.org",
    description: "Comprehensive project connecting React client with Node backend and persistent relational SQL database.",
    sequence_no: 1,
    created_at: "2026-08-01 09:52:00",
    updated_at: "2026-08-01 09:52:00"
  },
  {
    video_id: "vid-101-5-2",
    module_id: "mod-101-5",
    course_id: "crs-101",
    title: "Relational Database Design & SQL for Full-Stack Developers",
    youtube_video_id: "HXV3zeRR3h4",
    youtube_url: "https://www.youtube.com/watch?v=HXV3zeRR3h4",
    embed_url: "https://www.youtube-nocookie.com/embed/HXV3zeRR3h4",
    thumbnail_url: "https://img.youtube.com/vi/HXV3zeRR3h4/hqdefault.jpg",
    duration: "04:20:10",
    duration_seconds: 15610,
    channel_name: "freeCodeCamp.org",
    description: "Primary keys, foreign keys, normalization (1NF-3NF), indexing, and ACID transaction guarantees.",
    sequence_no: 2,
    created_at: "2026-08-01 09:54:00",
    updated_at: "2026-08-01 09:54:00"
  },
  {
    video_id: "vid-101-5-3",
    module_id: "mod-101-5",
    course_id: "crs-101",
    title: "Deploying Modern Full-Stack Web Apps to Production",
    youtube_video_id: "1hhm5eaS8dE",
    youtube_url: "https://www.youtube.com/watch?v=1hhm5eaS8dE",
    embed_url: "https://www.youtube-nocookie.com/embed/1hhm5eaS8dE",
    thumbnail_url: "https://img.youtube.com/vi/1hhm5eaS8dE/hqdefault.jpg",
    duration: "28:40",
    duration_seconds: 1720,
    channel_name: "Jack Herrington",
    description: "Best practices for environment variables, multi-stage Docker builds, health checks, and cloud deployments.",
    sequence_no: 3,
    created_at: "2026-08-01 09:56:00",
    updated_at: "2026-08-01 09:56:00"
  },
  // ===================================================================
  // COURSE 2: crs-102 (Practical Data Science & Machine Learning)
  // ===================================================================
  // Module 102-1
  {
    video_id: "vid-102-1-1",
    module_id: "mod-102-1",
    course_id: "crs-102",
    title: "Python for Beginners - Full Data Science Course",
    youtube_video_id: "rfscVS0vtbw",
    youtube_url: "https://www.youtube.com/watch?v=rfscVS0vtbw",
    embed_url: "https://www.youtube-nocookie.com/embed/rfscVS0vtbw",
    thumbnail_url: "https://img.youtube.com/vi/rfscVS0vtbw/hqdefault.jpg",
    duration: "04:26:50",
    duration_seconds: 16010,
    channel_name: "freeCodeCamp.org",
    description: "Hands-on introduction to Python language constructs, lists, dictionaries, functions, and modules.",
    sequence_no: 1,
    created_at: "2026-08-05 10:42:00",
    updated_at: "2026-08-05 10:42:00"
  },
  {
    video_id: "vid-102-1-2",
    module_id: "mod-102-1",
    course_id: "crs-102",
    title: "NumPy Tutorial: Scientific Computing with Python",
    youtube_video_id: "QUT1VHiLmmI",
    youtube_url: "https://www.youtube.com/watch?v=QUT1VHiLmmI",
    embed_url: "https://www.youtube-nocookie.com/embed/QUT1VHiLmmI",
    thumbnail_url: "https://img.youtube.com/vi/QUT1VHiLmmI/hqdefault.jpg",
    duration: "01:00:25",
    duration_seconds: 3625,
    channel_name: "freeCodeCamp.org",
    description: "High-performance n-dimensional array operations, matrix mathematics, indexing, slicing, and broadcasting.",
    sequence_no: 2,
    created_at: "2026-08-05 10:44:00",
    updated_at: "2026-08-05 10:44:00"
  },
  {
    video_id: "vid-102-1-3",
    module_id: "mod-102-1",
    course_id: "crs-102",
    title: "Jupyter Notebooks for Data Science",
    youtube_video_id: "HW29067qPBk",
    youtube_url: "https://www.youtube.com/watch?v=HW29067qPBk",
    embed_url: "https://www.youtube-nocookie.com/embed/HW29067qPBk",
    thumbnail_url: "https://img.youtube.com/vi/HW29067qPBk/hqdefault.jpg",
    duration: "29:40",
    duration_seconds: 1780,
    channel_name: "Corey Schafer",
    description: "Interactive execution, markdown documentation, cell management, and data visualization workflows.",
    sequence_no: 3,
    created_at: "2026-08-05 10:46:00",
    updated_at: "2026-08-05 10:46:00"
  },
  // Module 102-2
  {
    video_id: "vid-102-2-1",
    module_id: "mod-102-2",
    course_id: "crs-102",
    title: "Data Analysis with Python and Pandas",
    youtube_video_id: "vmEHCJofslg",
    youtube_url: "https://www.youtube.com/watch?v=vmEHCJofslg",
    embed_url: "https://www.youtube-nocookie.com/embed/vmEHCJofslg",
    thumbnail_url: "https://img.youtube.com/vi/vmEHCJofslg/hqdefault.jpg",
    duration: "09:20:15",
    duration_seconds: 33615,
    channel_name: "freeCodeCamp.org",
    description: "Filtering, grouping, aggregating, merging, and reshaping tabular datasets using Pandas DataFrames.",
    sequence_no: 1,
    created_at: "2026-08-05 10:52:00",
    updated_at: "2026-08-05 10:52:00"
  },
  {
    video_id: "vid-102-2-2",
    module_id: "mod-102-2",
    course_id: "crs-102",
    title: "Data Cleaning in Python: Missing Data & Outliers",
    youtube_video_id: "bDhvCp3_lYw",
    youtube_url: "https://www.youtube.com/watch?v=bDhvCp3_lYw",
    embed_url: "https://www.youtube-nocookie.com/embed/bDhvCp3_lYw",
    thumbnail_url: "https://img.youtube.com/vi/bDhvCp3_lYw/hqdefault.jpg",
    duration: "38:20",
    duration_seconds: 2300,
    channel_name: "Ken Jee",
    description: "Systematic approach to handling null values, deduplication, string parsing, and categorical data encoding.",
    sequence_no: 2,
    created_at: "2026-08-05 10:54:00",
    updated_at: "2026-08-05 10:54:00"
  },
  {
    video_id: "vid-102-2-3",
    module_id: "mod-102-2",
    course_id: "crs-102",
    title: "Exploratory Data Analysis (EDA) Techniques",
    youtube_video_id: "xi0vhXFPegw",
    youtube_url: "https://www.youtube.com/watch?v=xi0vhXFPegw",
    embed_url: "https://www.youtube-nocookie.com/embed/xi0vhXFPegw",
    thumbnail_url: "https://img.youtube.com/vi/xi0vhXFPegw/hqdefault.jpg",
    duration: "44:10",
    duration_seconds: 2650,
    channel_name: "freeCodeCamp.org",
    description: "Statistical summaries, correlation heatmaps, feature distributions, and visual pattern discovery.",
    sequence_no: 3,
    created_at: "2026-08-05 10:56:00",
    updated_at: "2026-08-05 10:56:00"
  },
  // Module 102-3
  {
    video_id: "vid-102-3-1",
    module_id: "mod-102-3",
    course_id: "crs-102",
    title: "Statistics for Data Science - Full Course",
    youtube_video_id: "Vfo5le26IhY",
    youtube_url: "https://www.youtube.com/watch?v=Vfo5le26IhY",
    embed_url: "https://www.youtube-nocookie.com/embed/Vfo5le26IhY",
    thumbnail_url: "https://img.youtube.com/vi/Vfo5le26IhY/hqdefault.jpg",
    duration: "08:05:10",
    duration_seconds: 29110,
    channel_name: "freeCodeCamp.org",
    description: "Comprehensive probability theory, random variables, expected values, variance, and Central Limit Theorem.",
    sequence_no: 1,
    created_at: "2026-08-05 11:02:00",
    updated_at: "2026-08-05 11:02:00"
  },
  {
    video_id: "vid-102-3-2",
    module_id: "mod-102-3",
    course_id: "crs-102",
    title: "Hypothesis Testing and P-Values Clearly Explained",
    youtube_video_id: "0oc49DyA3hU",
    youtube_url: "https://www.youtube.com/watch?v=0oc49DyA3hU",
    embed_url: "https://www.youtube-nocookie.com/embed/0oc49DyA3hU",
    thumbnail_url: "https://img.youtube.com/vi/0oc49DyA3hU/hqdefault.jpg",
    duration: "25:40",
    duration_seconds: 1540,
    channel_name: "StatQuest with Josh Starmer",
    description: "Intuitive visual explanation of null hypothesis formulation, significance level alpha, and p-value mechanics.",
    sequence_no: 2,
    created_at: "2026-08-05 11:04:00",
    updated_at: "2026-08-05 11:04:00"
  },
  {
    video_id: "vid-102-3-3",
    module_id: "mod-102-3",
    course_id: "crs-102",
    title: "The Normal Distribution, Z-Scores and Standard Deviation",
    youtube_video_id: "rzFX5NWojp0",
    youtube_url: "https://www.youtube.com/watch?v=rzFX5NWojp0",
    embed_url: "https://www.youtube-nocookie.com/embed/rzFX5NWojp0",
    thumbnail_url: "https://img.youtube.com/vi/rzFX5NWojp0/hqdefault.jpg",
    duration: "16:15",
    duration_seconds: 975,
    channel_name: "StatQuest with Josh Starmer",
    description: "Gaussian bell curves, standard normal transformation, 68-95-99.7 empirical rule, and percentile computation.",
    sequence_no: 3,
    created_at: "2026-08-05 11:06:00",
    updated_at: "2026-08-05 11:06:00"
  },
  // Module 102-4
  {
    video_id: "vid-102-4-1",
    module_id: "mod-102-4",
    course_id: "crs-102",
    title: "Machine Learning for Everybody - Full Course",
    youtube_video_id: "i_LwzRVP7bg",
    youtube_url: "https://www.youtube.com/watch?v=i_LwzRVP7bg",
    embed_url: "https://www.youtube-nocookie.com/embed/i_LwzRVP7bg",
    thumbnail_url: "https://img.youtube.com/vi/i_LwzRVP7bg/hqdefault.jpg",
    duration: "03:55:20",
    duration_seconds: 14120,
    channel_name: "freeCodeCamp.org",
    description: "Supervised regression, classification, k-nearest neighbors, naive Bayes, and logistic regression.",
    sequence_no: 1,
    created_at: "2026-08-05 11:12:00",
    updated_at: "2026-08-05 11:12:00"
  },
  {
    video_id: "vid-102-4-2",
    module_id: "mod-102-4",
    course_id: "crs-102",
    title: "Scikit-Learn Machine Learning in Python",
    youtube_video_id: "0B5eIE_1vpU",
    youtube_url: "https://www.youtube.com/watch?v=0B5eIE_1vpU",
    embed_url: "https://www.youtube-nocookie.com/embed/0B5eIE_1vpU",
    thumbnail_url: "https://img.youtube.com/vi/0B5eIE_1vpU/hqdefault.jpg",
    duration: "46:12",
    duration_seconds: 2772,
    channel_name: "freeCodeCamp.org",
    description: "Model pipelines, train/test splitting, cross-validation, feature scaling, and GridSearchCV.",
    sequence_no: 2,
    created_at: "2026-08-05 11:14:00",
    updated_at: "2026-08-05 11:14:00"
  },
  {
    video_id: "vid-102-4-3",
    module_id: "mod-102-4",
    course_id: "crs-102",
    title: "Random Forests, Decision Trees & Ensemble Methods",
    youtube_video_id: "J4Wdy0Wc_xQ",
    youtube_url: "https://www.youtube.com/watch?v=J4Wdy0Wc_xQ",
    embed_url: "https://www.youtube-nocookie.com/embed/J4Wdy0Wc_xQ",
    thumbnail_url: "https://img.youtube.com/vi/J4Wdy0Wc_xQ/hqdefault.jpg",
    duration: "28:30",
    duration_seconds: 1710,
    channel_name: "StatQuest with Josh Starmer",
    description: "Bagging, bootstrap aggregation, out-of-bag error estimation, and feature importance rankings.",
    sequence_no: 3,
    created_at: "2026-08-05 11:16:00",
    updated_at: "2026-08-05 11:16:00"
  },
  // Module 102-5
  {
    video_id: "vid-102-5-1",
    module_id: "mod-102-5",
    course_id: "crs-102",
    title: "But what is a neural network? | Deep Learning Chapter 1",
    youtube_video_id: "aircAruvnKk",
    youtube_url: "https://www.youtube.com/watch?v=aircAruvnKk",
    embed_url: "https://www.youtube-nocookie.com/embed/aircAruvnKk",
    thumbnail_url: "https://img.youtube.com/vi/aircAruvnKk/hqdefault.jpg",
    duration: "19:13",
    duration_seconds: 1153,
    channel_name: "3Blue1Brown",
    description: "Geometric intuition of multilayer perceptrons, weights, biases, and non-linear activation functions.",
    sequence_no: 1,
    created_at: "2026-08-05 11:22:00",
    updated_at: "2026-08-05 11:22:00"
  },
  {
    video_id: "vid-102-5-2",
    module_id: "mod-102-5",
    course_id: "crs-102",
    title: "PyTorch for Deep Learning Bootcamp",
    youtube_video_id: "V_xro1bcAuA",
    youtube_url: "https://www.youtube.com/watch?v=V_xro1bcAuA",
    embed_url: "https://www.youtube-nocookie.com/embed/V_xro1bcAuA",
    thumbnail_url: "https://img.youtube.com/vi/V_xro1bcAuA/hqdefault.jpg",
    duration: "25:40:00",
    duration_seconds: 92400,
    channel_name: "freeCodeCamp.org",
    description: "PyTorch tensor computations, computational graphs, autograd automatic differentiation, and GPU training.",
    sequence_no: 2,
    created_at: "2026-08-05 11:24:00",
    updated_at: "2026-08-05 11:24:00"
  },
  {
    video_id: "vid-102-5-3",
    module_id: "mod-102-5",
    course_id: "crs-102",
    title: "Machine Learning Model Deployment and MLOps",
    youtube_video_id: "8_L_6BffQvE",
    youtube_url: "https://www.youtube.com/watch?v=8_L_6BffQvE",
    embed_url: "https://www.youtube-nocookie.com/embed/8_L_6BffQvE",
    thumbnail_url: "https://img.youtube.com/vi/8_L_6BffQvE/hqdefault.jpg",
    duration: "35:10",
    duration_seconds: 2110,
    channel_name: "freeCodeCamp.org",
    description: "Packaging predictive models behind REST endpoints, containerization, inference latency, and drift detection.",
    sequence_no: 3,
    created_at: "2026-08-05 11:26:00",
    updated_at: "2026-08-05 11:26:00"
  },
  // ===================================================================
  // COURSE 3: crs-103 (Cloud Infrastructure & DevOps Mastery)
  // ===================================================================
  // Module 103-1
  {
    video_id: "vid-103-1-1",
    module_id: "mod-103-1",
    course_id: "crs-103",
    title: "Linux for Beginners - Complete Command Line Course",
    youtube_video_id: "sWbUDq4S6Y8",
    youtube_url: "https://www.youtube.com/watch?v=sWbUDq4S6Y8",
    embed_url: "https://www.youtube-nocookie.com/embed/sWbUDq4S6Y8",
    thumbnail_url: "https://img.youtube.com/vi/sWbUDq4S6Y8/hqdefault.jpg",
    duration: "05:15:30",
    duration_seconds: 18930,
    channel_name: "freeCodeCamp.org",
    description: "Master the bash shell, file navigation, piping, redirection, environment variables, and text processing.",
    sequence_no: 1,
    created_at: "2026-08-10 11:27:00",
    updated_at: "2026-08-10 11:27:00"
  },
  {
    video_id: "vid-103-1-2",
    module_id: "mod-103-1",
    course_id: "crs-103",
    title: "Bash Scripting Tutorial for Automation",
    youtube_video_id: "tA_qMdzvC50",
    youtube_url: "https://www.youtube.com/watch?v=tA_qMdzvC50",
    embed_url: "https://www.youtube-nocookie.com/embed/tA_qMdzvC50",
    thumbnail_url: "https://img.youtube.com/vi/tA_qMdzvC50/hqdefault.jpg",
    duration: "42:15",
    duration_seconds: 2535,
    channel_name: "freeCodeCamp.org",
    description: "Writing reusable shell scripts with conditionals, loops, functions, arguments, and exit status codes.",
    sequence_no: 2,
    created_at: "2026-08-10 11:29:00",
    updated_at: "2026-08-10 11:29:00"
  },
  {
    video_id: "vid-103-1-3",
    module_id: "mod-103-1",
    course_id: "crs-103",
    title: "Linux Permissions, Chmod & Chown Explained",
    youtube_video_id: "41dU2z9qYkQ",
    youtube_url: "https://www.youtube.com/watch?v=41dU2z9qYkQ",
    embed_url: "https://www.youtube-nocookie.com/embed/41dU2z9qYkQ",
    thumbnail_url: "https://img.youtube.com/vi/41dU2z9qYkQ/hqdefault.jpg",
    duration: "21:40",
    duration_seconds: 1300,
    channel_name: "NetworkChuck",
    description: "Read, write, execute octal permissions, user/group ownership, SUID bits, and sudoer security policies.",
    sequence_no: 3,
    created_at: "2026-08-10 11:31:00",
    updated_at: "2026-08-10 11:31:00"
  },
  // Module 103-2
  {
    video_id: "vid-103-2-1",
    module_id: "mod-103-2",
    course_id: "crs-103",
    title: "Docker Tutorial for Beginners - Full Course",
    youtube_video_id: "fqMOX6JJhGo",
    youtube_url: "https://www.youtube.com/watch?v=fqMOX6JJhGo",
    embed_url: "https://www.youtube-nocookie.com/embed/fqMOX6JJhGo",
    thumbnail_url: "https://img.youtube.com/vi/fqMOX6JJhGo/hqdefault.jpg",
    duration: "02:10:45",
    duration_seconds: 7845,
    channel_name: "TechWorld with Nana",
    description: "Container architecture, Docker daemon, writing Dockerfiles, volume persistence, and port mapping.",
    sequence_no: 1,
    created_at: "2026-08-10 11:37:00",
    updated_at: "2026-08-10 11:37:00"
  },
  {
    video_id: "vid-103-2-2",
    module_id: "mod-103-2",
    course_id: "crs-103",
    title: "Docker in 100 Seconds",
    youtube_video_id: "Gjnup-PuquQ",
    youtube_url: "https://www.youtube.com/watch?v=Gjnup-PuquQ",
    embed_url: "https://www.youtube-nocookie.com/embed/Gjnup-PuquQ",
    thumbnail_url: "https://img.youtube.com/vi/Gjnup-PuquQ/hqdefault.jpg",
    duration: "02:22",
    duration_seconds: 142,
    channel_name: "Fireship",
    description: "Concise review of OS-level virtualization, container images, registries, and runtime isolation.",
    sequence_no: 2,
    created_at: "2026-08-10 11:39:00",
    updated_at: "2026-08-10 11:39:00"
  },
  {
    video_id: "vid-103-2-3",
    module_id: "mod-103-2",
    course_id: "crs-103",
    title: "Docker Compose & Multi-Container Workflows",
    youtube_video_id: "3c-iBn73dDE",
    youtube_url: "https://www.youtube.com/watch?v=3c-iBn73dDE",
    embed_url: "https://www.youtube-nocookie.com/embed/3c-iBn73dDE",
    thumbnail_url: "https://img.youtube.com/vi/3c-iBn73dDE/hqdefault.jpg",
    duration: "24:50",
    duration_seconds: 1490,
    channel_name: "Traversy Media",
    description: "Orchestrating microservices with docker-compose.yml: networks, shared volumes, and secret management.",
    sequence_no: 3,
    created_at: "2026-08-10 11:41:00",
    updated_at: "2026-08-10 11:41:00"
  },
  // Module 103-3
  {
    video_id: "vid-103-3-1",
    module_id: "mod-103-3",
    course_id: "crs-103",
    title: "GitHub Actions CI/CD Full Course",
    youtube_video_id: "R8_veQiYWrI",
    youtube_url: "https://www.youtube.com/watch?v=R8_veQiYWrI",
    embed_url: "https://www.youtube-nocookie.com/embed/R8_veQiYWrI",
    thumbnail_url: "https://img.youtube.com/vi/R8_veQiYWrI/hqdefault.jpg",
    duration: "01:45:20",
    duration_seconds: 6320,
    channel_name: "TechWorld with Nana",
    description: "Configuring workflow triggers, matrix jobs, runner environments, secrets, and automated releases.",
    sequence_no: 1,
    created_at: "2026-08-10 11:47:00",
    updated_at: "2026-08-10 11:47:00"
  },
  {
    video_id: "vid-103-3-2",
    module_id: "mod-103-3",
    course_id: "crs-103",
    title: "CI/CD Pipelines Explained in 5 Minutes",
    youtube_video_id: "scEDHsr3APg",
    youtube_url: "https://www.youtube.com/watch?v=scEDHsr3APg",
    embed_url: "https://www.youtube-nocookie.com/embed/scEDHsr3APg",
    thumbnail_url: "https://img.youtube.com/vi/scEDHsr3APg/hqdefault.jpg",
    duration: "05:12",
    duration_seconds: 312,
    channel_name: "freeCodeCamp.org",
    description: "Continuous Integration build loops, automated test suites, staging environments, and zero-downtime deployment.",
    sequence_no: 2,
    created_at: "2026-08-10 11:49:00",
    updated_at: "2026-08-10 11:49:00"
  },
  {
    video_id: "vid-103-3-3",
    module_id: "mod-103-3",
    course_id: "crs-103",
    title: "Automated Testing in Continuous Delivery",
    youtube_video_id: "3e_f5X92gRk",
    youtube_url: "https://www.youtube.com/watch?v=3e_f5X92gRk",
    embed_url: "https://www.youtube-nocookie.com/embed/3e_f5X92gRk",
    thumbnail_url: "https://img.youtube.com/vi/3e_f5X92gRk/hqdefault.jpg",
    duration: "29:30",
    duration_seconds: 1770,
    channel_name: "Continuous Delivery",
    description: "Test pyramid strategy: unit testing speed, integration validation, and blue/green release safety gates.",
    sequence_no: 3,
    created_at: "2026-08-10 11:51:00",
    updated_at: "2026-08-10 11:51:00"
  },
  // Module 103-4
  {
    video_id: "vid-103-4-1",
    module_id: "mod-103-4",
    course_id: "crs-103",
    title: "Kubernetes Tutorial for Beginners [Full Course]",
    youtube_video_id: "X48VuDVv0do",
    youtube_url: "https://www.youtube.com/watch?v=X48VuDVv0do",
    embed_url: "https://www.youtube-nocookie.com/embed/X48VuDVv0do",
    thumbnail_url: "https://img.youtube.com/vi/X48VuDVv0do/hqdefault.jpg",
    duration: "03:58:10",
    duration_seconds: 14290,
    channel_name: "TechWorld with Nana",
    description: "K8s architecture, kubectl commands, declarative YAML specs, services, ingress, and namespace isolation.",
    sequence_no: 1,
    created_at: "2026-08-10 11:57:00",
    updated_at: "2026-08-10 11:57:00"
  },
  {
    video_id: "vid-103-4-2",
    module_id: "mod-103-4",
    course_id: "crs-103",
    title: "Kubernetes in 100 Seconds",
    youtube_video_id: "d6WC5n9G_vM",
    youtube_url: "https://www.youtube.com/watch?v=d6WC5n9G_vM",
    embed_url: "https://www.youtube-nocookie.com/embed/d6WC5n9G_vM",
    thumbnail_url: "https://img.youtube.com/vi/d6WC5n9G_vM/hqdefault.jpg",
    duration: "02:28",
    duration_seconds: 148,
    channel_name: "Fireship",
    description: "High-speed overview of container orchestration, automated scaling, self-healing pods, and load balancing.",
    sequence_no: 2,
    created_at: "2026-08-10 11:59:00",
    updated_at: "2026-08-10 11:59:00"
  },
  {
    video_id: "vid-103-4-3",
    module_id: "mod-103-4",
    course_id: "crs-103",
    title: "Kubernetes Architecture Explained: Control Plane vs Workers",
    youtube_video_id: "umXEmn3cMWY",
    youtube_url: "https://www.youtube.com/watch?v=umXEmn3cMWY",
    embed_url: "https://www.youtube-nocookie.com/embed/umXEmn3cMWY",
    thumbnail_url: "https://img.youtube.com/vi/umXEmn3cMWY/hqdefault.jpg",
    duration: "18:25",
    duration_seconds: 1105,
    channel_name: "IBM Technology",
    description: "Detailed analysis of API Server, etcd distributed store, kube-scheduler, kubelet, and kube-proxy.",
    sequence_no: 3,
    created_at: "2026-08-10 12:01:00",
    updated_at: "2026-08-10 12:01:00"
  },
  // Module 103-5
  {
    video_id: "vid-103-5-1",
    module_id: "mod-103-5",
    course_id: "crs-103",
    title: "Terraform Course - Automate Your Cloud Infrastructure",
    youtube_video_id: "SLB_c_daJDC",
    youtube_url: "https://www.youtube.com/watch?v=SLB_c_daJDC",
    embed_url: "https://www.youtube-nocookie.com/embed/SLB_c_daJDC",
    thumbnail_url: "https://img.youtube.com/vi/SLB_c_daJDC/hqdefault.jpg",
    duration: "02:20:15",
    duration_seconds: 8415,
    channel_name: "freeCodeCamp.org",
    description: "HCL syntax, provider configurations, terraform plan and apply, state locking, and modular cloud architectures.",
    sequence_no: 1,
    created_at: "2026-08-10 12:07:00",
    updated_at: "2026-08-10 12:07:00"
  },
  {
    video_id: "vid-103-5-2",
    module_id: "mod-103-5",
    course_id: "crs-103",
    title: "Prometheus & Grafana Monitoring Full Tutorial",
    youtube_video_id: "h4Sl21AK9g8",
    youtube_url: "https://www.youtube.com/watch?v=h4Sl21AK9g8",
    embed_url: "https://www.youtube-nocookie.com/embed/h4Sl21AK9g8",
    thumbnail_url: "https://img.youtube.com/vi/h4Sl21AK9g8/hqdefault.jpg",
    duration: "45:10",
    duration_seconds: 2710,
    channel_name: "TechWorld with Nana",
    description: "Time-series metric collection, PromQL query language, exporter integration, and alerting rules in Grafana.",
    sequence_no: 2,
    created_at: "2026-08-10 12:09:00",
    updated_at: "2026-08-10 12:09:00"
  },
  {
    video_id: "vid-103-5-3",
    module_id: "mod-103-5",
    course_id: "crs-103",
    title: "Cloud Security & Zero-Trust Architecture",
    youtube_video_id: "vJ9_4b7w8eQ",
    youtube_url: "https://www.youtube.com/watch?v=vJ9_4b7w8eQ",
    embed_url: "https://www.youtube-nocookie.com/embed/vJ9_4b7w8eQ",
    thumbnail_url: "https://img.youtube.com/vi/vJ9_4b7w8eQ/hqdefault.jpg",
    duration: "26:40",
    duration_seconds: 1600,
    channel_name: "IBM Technology",
    description: "Never trust, always verify: identity-based access control, least privilege enforcement, and encrypted network transit.",
    sequence_no: 3,
    created_at: "2026-08-10 12:11:00",
    updated_at: "2026-08-10 12:11:00"
  },
  // ===================================================================
  // COURSE 4: crs-104 (Applied Cybersecurity & Threat Defense)
  // ===================================================================
  // Module 104-1
  {
    video_id: "vid-104-1-1",
    module_id: "mod-104-1",
    course_id: "crs-104",
    title: "Computer Networking Full Course for Beginners",
    youtube_video_id: "IPvYxKW3WTo",
    youtube_url: "https://www.youtube.com/watch?v=IPvYxKW3WTo",
    embed_url: "https://www.youtube-nocookie.com/embed/IPvYxKW3WTo",
    thumbnail_url: "https://img.youtube.com/vi/IPvYxKW3WTo/hqdefault.jpg",
    duration: "04:12:30",
    duration_seconds: 15150,
    channel_name: "freeCodeCamp.org",
    description: "Ethernet framing, IP addressing, routing tables, ICMP, DHCP, DNS, and fundamental network architectures.",
    sequence_no: 1,
    created_at: "2026-08-15 14:12:00",
    updated_at: "2026-08-15 14:12:00"
  },
  {
    video_id: "vid-104-1-2",
    module_id: "mod-104-1",
    course_id: "crs-104",
    title: "Wireshark Packet Analysis Masterclass",
    youtube_video_id: "qiQR5rTSshw",
    youtube_url: "https://www.youtube.com/watch?v=qiQR5rTSshw",
    embed_url: "https://www.youtube-nocookie.com/embed/qiQR5rTSshw",
    thumbnail_url: "https://img.youtube.com/vi/qiQR5rTSshw/hqdefault.jpg",
    duration: "34:20",
    duration_seconds: 2060,
    channel_name: "NetworkChuck",
    description: "Sniffing network traffic, filtering protocols, reconstructing TCP streams, and identifying plaintext credentials.",
    sequence_no: 2,
    created_at: "2026-08-15 14:14:00",
    updated_at: "2026-08-15 14:14:00"
  },
  {
    video_id: "vid-104-1-3",
    module_id: "mod-104-1",
    course_id: "crs-104",
    title: "TCP/IP Handshake & Ports Animated Breakdown",
    youtube_video_id: "5WFItsX5gkQ",
    youtube_url: "https://www.youtube.com/watch?v=5WFItsX5gkQ",
    embed_url: "https://www.youtube-nocookie.com/embed/5WFItsX5gkQ",
    thumbnail_url: "https://img.youtube.com/vi/5WFItsX5gkQ/hqdefault.jpg",
    duration: "22:15",
    duration_seconds: 1335,
    channel_name: "PowerCert Animated Videos",
    description: "SYN, SYN-ACK, ACK packet exchange, sequence numbers, window sizing, and port allocation mechanisms.",
    sequence_no: 3,
    created_at: "2026-08-15 14:16:00",
    updated_at: "2026-08-15 14:16:00"
  },
  // Module 104-2
  {
    video_id: "vid-104-2-1",
    module_id: "mod-104-2",
    course_id: "crs-104",
    title: "Ethical Hacking in 12 Hours - Full Course",
    youtube_video_id: "3Kq1MIfTWCE",
    youtube_url: "https://www.youtube.com/watch?v=3Kq1MIfTWCE",
    embed_url: "https://www.youtube-nocookie.com/embed/3Kq1MIfTWCE",
    thumbnail_url: "https://img.youtube.com/vi/3Kq1MIfTWCE/hqdefault.jpg",
    duration: "12:00:10",
    duration_seconds: 43210,
    channel_name: "The Cyber Mentor",
    description: "Methodical penetration testing methodology: reconnaissance, scanning, vulnerability analysis, and remediation.",
    sequence_no: 1,
    created_at: "2026-08-15 14:22:00",
    updated_at: "2026-08-15 14:22:00"
  },
  {
    video_id: "vid-104-2-2",
    module_id: "mod-104-2",
    course_id: "crs-104",
    title: "Nmap Network Scanning & Port Enumeration",
    youtube_video_id: "inWWhr5tnEA",
    youtube_url: "https://www.youtube.com/watch?v=inWWhr5tnEA",
    embed_url: "https://www.youtube-nocookie.com/embed/inWWhr5tnEA",
    thumbnail_url: "https://img.youtube.com/vi/inWWhr5tnEA/hqdefault.jpg",
    duration: "28:40",
    duration_seconds: 1720,
    channel_name: "NetworkChuck",
    description: "SYN stealth scans, service version detection (-sV), default NSE scripts (-sC), and operating system fingerprinting.",
    sequence_no: 2,
    created_at: "2026-08-15 14:24:00",
    updated_at: "2026-08-15 14:24:00"
  },
  {
    video_id: "vid-104-2-3",
    module_id: "mod-104-2",
    course_id: "crs-104",
    title: "Threat Modeling Explained: STRIDE Methodology",
    youtube_video_id: "2_lswM1S264",
    youtube_url: "https://www.youtube.com/watch?v=2_lswM1S264",
    embed_url: "https://www.youtube-nocookie.com/embed/2_lswM1S264",
    thumbnail_url: "https://img.youtube.com/vi/2_lswM1S264/hqdefault.jpg",
    duration: "17:30",
    duration_seconds: 1050,
    channel_name: "IBM Technology",
    description: "Deconstructing software boundaries: Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege.",
    sequence_no: 3,
    created_at: "2026-08-15 14:26:00",
    updated_at: "2026-08-15 14:26:00"
  },
  // Module 104-3
  {
    video_id: "vid-104-3-1",
    module_id: "mod-104-3",
    course_id: "crs-104",
    title: "OWASP Top 10 Web Vulnerabilities Explained",
    youtube_video_id: "24fHLWs_Sqc",
    youtube_url: "https://www.youtube.com/watch?v=24fHLWs_Sqc",
    embed_url: "https://www.youtube-nocookie.com/embed/24fHLWs_Sqc",
    thumbnail_url: "https://img.youtube.com/vi/24fHLWs_Sqc/hqdefault.jpg",
    duration: "01:25:40",
    duration_seconds: 5140,
    channel_name: "freeCodeCamp.org",
    description: "Walkthrough of the modern OWASP Top 10 security risks with vulnerable code snippets and secure architectural remediations.",
    sequence_no: 1,
    created_at: "2026-08-15 14:32:00",
    updated_at: "2026-08-15 14:32:00"
  },
  {
    video_id: "vid-104-3-2",
    module_id: "mod-104-3",
    course_id: "crs-104",
    title: "SQL Injection Attacks & Parameterized Query Defense",
    youtube_video_id: "ciNHn38EyRc",
    youtube_url: "https://www.youtube.com/watch?v=ciNHn38EyRc",
    embed_url: "https://www.youtube-nocookie.com/embed/ciNHn38EyRc",
    thumbnail_url: "https://img.youtube.com/vi/ciNHn38EyRc/hqdefault.jpg",
    duration: "21:10",
    duration_seconds: 1270,
    channel_name: "Computerphile",
    description: "How unescaped string concatenation creates SQL injection vulnerabilities, and why prepared statements completely neutralize attacks.",
    sequence_no: 2,
    created_at: "2026-08-15 14:34:00",
    updated_at: "2026-08-15 14:34:00"
  },
  {
    video_id: "vid-104-3-3",
    module_id: "mod-104-3",
    course_id: "crs-104",
    title: "Cross-Site Scripting (XSS) & Content Security Policy",
    youtube_video_id: "EoaDgZug2VQ",
    youtube_url: "https://www.youtube.com/watch?v=EoaDgZug2VQ",
    embed_url: "https://www.youtube-nocookie.com/embed/EoaDgZug2VQ",
    thumbnail_url: "https://img.youtube.com/vi/EoaDgZug2VQ/hqdefault.jpg",
    duration: "19:50",
    duration_seconds: 1190,
    channel_name: "Computerphile",
    description: "Reflected, stored, and DOM-based XSS attacks, cookie theft mechanics, and mitigating with CSP headers and output encoding.",
    sequence_no: 3,
    created_at: "2026-08-15 14:36:00",
    updated_at: "2026-08-15 14:36:00"
  },
  // Module 104-4
  {
    video_id: "vid-104-4-1",
    module_id: "mod-104-4",
    course_id: "crs-104",
    title: "Cryptography Full Course for Beginners",
    youtube_video_id: "jhXCTbFnK8o",
    youtube_url: "https://www.youtube.com/watch?v=jhXCTbFnK8o",
    embed_url: "https://www.youtube-nocookie.com/embed/jhXCTbFnK8o",
    thumbnail_url: "https://img.youtube.com/vi/jhXCTbFnK8o/hqdefault.jpg",
    duration: "02:40:20",
    duration_seconds: 9620,
    channel_name: "freeCodeCamp.org",
    description: "History of ciphers, one-time pads, block ciphers, stream ciphers, public key cryptography, and digital signatures.",
    sequence_no: 1,
    created_at: "2026-08-15 14:42:00",
    updated_at: "2026-08-15 14:42:00"
  },
  {
    video_id: "vid-104-4-2",
    module_id: "mod-104-4",
    course_id: "crs-104",
    title: "Public Key Cryptography & RSA Explained",
    youtube_video_id: "GSIDS_lvRv4",
    youtube_url: "https://www.youtube.com/watch?v=GSIDS_lvRv4",
    embed_url: "https://www.youtube-nocookie.com/embed/GSIDS_lvRv4",
    thumbnail_url: "https://img.youtube.com/vi/GSIDS_lvRv4/hqdefault.jpg",
    duration: "12:45",
    duration_seconds: 765,
    channel_name: "Computerphile",
    description: "Mathematical foundations of asymmetric key pairs, prime factor difficulty, Euler totient theorem, and modular exponentiation.",
    sequence_no: 2,
    created_at: "2026-08-15 14:44:00",
    updated_at: "2026-08-15 14:44:00"
  },
  {
    video_id: "vid-104-4-3",
    module_id: "mod-104-4",
    course_id: "crs-104",
    title: "TLS / SSL Handshake Step-by-Step Breakdown",
    youtube_video_id: "86cQCE8XmKY",
    youtube_url: "https://www.youtube.com/watch?v=86cQCE8XmKY",
    embed_url: "https://www.youtube-nocookie.com/embed/86cQCE8XmKY",
    thumbnail_url: "https://img.youtube.com/vi/86cQCE8XmKY/hqdefault.jpg",
    duration: "15:30",
    duration_seconds: 930,
    channel_name: "Computerphile",
    description: "How client and server establish an encrypted TLS tunnel using certificates, Diffie-Hellman ephemeral key exchanges, and AES-GCM.",
    sequence_no: 3,
    created_at: "2026-08-15 14:46:00",
    updated_at: "2026-08-15 14:46:00"
  },
  // Module 104-5
  {
    video_id: "vid-104-5-1",
    module_id: "mod-104-5",
    course_id: "crs-104",
    title: "Incident Response Lifecycle: NIST & SANS Framework",
    youtube_video_id: "3ZtqfKqV4r0",
    youtube_url: "https://www.youtube.com/watch?v=3ZtqfKqV4r0",
    embed_url: "https://www.youtube-nocookie.com/embed/3ZtqfKqV4r0",
    thumbnail_url: "https://img.youtube.com/vi/3ZtqfKqV4r0/hqdefault.jpg",
    duration: "28:10",
    duration_seconds: 1690,
    channel_name: "IBM Technology",
    description: "Preparation, Detection & Analysis, Containment, Eradication, Recovery, and Post-Incident Lessons Learned.",
    sequence_no: 1,
    created_at: "2026-08-15 14:52:00",
    updated_at: "2026-08-15 14:52:00"
  },
  {
    video_id: "vid-104-5-2",
    module_id: "mod-104-5",
    course_id: "crs-104",
    title: "Digital Forensics & Memory Analysis Essentials",
    youtube_video_id: "J6zM2x4e8u4",
    youtube_url: "https://www.youtube.com/watch?v=J6zM2x4e8u4",
    embed_url: "https://www.youtube-nocookie.com/embed/J6zM2x4e8u4",
    thumbnail_url: "https://img.youtube.com/vi/J6zM2x4e8u4/hqdefault.jpg",
    duration: "42:30",
    duration_seconds: 2550,
    channel_name: "freeCodeCamp.org",
    description: "Live memory triage with Volatility, chain of custody preservation, disk imaging, and filesystem timeline analysis.",
    sequence_no: 2,
    created_at: "2026-08-15 14:54:00",
    updated_at: "2026-08-15 14:54:00"
  },
  {
    video_id: "vid-104-5-3",
    module_id: "mod-104-5",
    course_id: "crs-104",
    title: "SOC Analyst Fundamentals & Threat Hunting Basics",
    youtube_video_id: "fNZfD1qFv_U",
    youtube_url: "https://www.youtube.com/watch?v=fNZfD1qFv_U",
    embed_url: "https://www.youtube-nocookie.com/embed/fNZfD1qFv_U",
    thumbnail_url: "https://img.youtube.com/vi/fNZfD1qFv_U/hqdefault.jpg",
    duration: "31:15",
    duration_seconds: 1875,
    channel_name: "NetworkChuck",
    description: "Analyzing security alerts in a Security Operations Center (SOC), hunting adversary indicators, and pivoting on IoCs.",
    sequence_no: 3,
    created_at: "2026-08-15 14:56:00",
    updated_at: "2026-08-15 14:56:00"
  },
  // ===================================================================
  // COURSE 5: crs-105 (Enterprise UI/UX Design Systems)
  // ===================================================================
  // Module 105-1
  {
    video_id: "vid-105-1-1",
    module_id: "mod-105-1",
    course_id: "crs-105",
    title: "UX Design Course for Beginners",
    youtube_video_id: "c94nyJV073I",
    youtube_url: "https://www.youtube.com/watch?v=c94nyJV073I",
    embed_url: "https://www.youtube-nocookie.com/embed/c94nyJV073I",
    thumbnail_url: "https://img.youtube.com/vi/c94nyJV073I/hqdefault.jpg",
    duration: "02:15:30",
    duration_seconds: 8130,
    channel_name: "freeCodeCamp.org",
    description: "The UX design process from discovery through delivery, user interviews, journey mapping, and empathy building.",
    sequence_no: 1,
    created_at: "2026-08-20 16:32:00",
    updated_at: "2026-08-20 16:32:00"
  },
  {
    video_id: "vid-105-1-2",
    module_id: "mod-105-1",
    course_id: "crs-105",
    title: "What is Design Thinking? 5 Stages Explained",
    youtube_video_id: "gHGN6hs2gZY",
    youtube_url: "https://www.youtube.com/watch?v=gHGN6hs2gZY",
    embed_url: "https://www.youtube-nocookie.com/embed/gHGN6hs2gZY",
    thumbnail_url: "https://img.youtube.com/vi/gHGN6hs2gZY/hqdefault.jpg",
    duration: "14:20",
    duration_seconds: 860,
    channel_name: "CareerFoundry",
    description: "Stanford d.school 5-stage framework: Empathize, Define, Ideate, Prototype, and Test for iterative product innovation.",
    sequence_no: 2,
    created_at: "2026-08-20 16:34:00",
    updated_at: "2026-08-20 16:34:00"
  },
  {
    video_id: "vid-105-1-3",
    module_id: "mod-105-1",
    course_id: "crs-105",
    title: "User Research Methodologies & Persona Creation",
    youtube_video_id: "0V5BwQLGeBM",
    youtube_url: "https://www.youtube.com/watch?v=0V5BwQLGeBM",
    embed_url: "https://www.youtube-nocookie.com/embed/0V5BwQLGeBM",
    thumbnail_url: "https://img.youtube.com/vi/0V5BwQLGeBM/hqdefault.jpg",
    duration: "23:10",
    duration_seconds: 1390,
    channel_name: "Flux Academy",
    description: "Transforming qualitative user research into actionable user personas, pain point clusters, and jobs-to-be-done.",
    sequence_no: 3,
    created_at: "2026-08-20 16:36:00",
    updated_at: "2026-08-20 16:36:00"
  },
  // Module 105-2
  {
    video_id: "vid-105-2-1",
    module_id: "mod-105-2",
    course_id: "crs-105",
    title: "Wireframing for UX Beginners Step-by-Step",
    youtube_video_id: "q_b4gP1kEVE",
    youtube_url: "https://www.youtube.com/watch?v=q_b4gP1kEVE",
    embed_url: "https://www.youtube-nocookie.com/embed/q_b4gP1kEVE",
    thumbnail_url: "https://img.youtube.com/vi/q_b4gP1kEVE/hqdefault.jpg",
    duration: "28:40",
    duration_seconds: 1720,
    channel_name: "AJ&Smart",
    description: "Rapid low-fidelity sketching, structural layout decisions without color distraction, and user flow alignment.",
    sequence_no: 1,
    created_at: "2026-08-20 16:42:00",
    updated_at: "2026-08-20 16:42:00"
  },
  {
    video_id: "vid-105-2-2",
    module_id: "mod-105-2",
    course_id: "crs-105",
    title: "Figma for UI Design - Full Course",
    youtube_video_id: "FTFaQWZBqQ8",
    youtube_url: "https://www.youtube.com/watch?v=FTFaQWZBqQ8",
    embed_url: "https://www.youtube-nocookie.com/embed/FTFaQWZBqQ8",
    thumbnail_url: "https://img.youtube.com/vi/FTFaQWZBqQ8/hqdefault.jpg",
    duration: "03:40:15",
    duration_seconds: 13215,
    channel_name: "freeCodeCamp.org",
    description: "Frames, vectors, styles, auto-layout constraints, responsive components, and interactive prototype transitions.",
    sequence_no: 2,
    created_at: "2026-08-20 16:44:00",
    updated_at: "2026-08-20 16:44:00"
  },
  {
    video_id: "vid-105-2-3",
    module_id: "mod-105-2",
    course_id: "crs-105",
    title: "User Flow Diagrams & Information Architecture",
    youtube_video_id: "wI2vs9f0tQY",
    youtube_url: "https://www.youtube.com/watch?v=wI2vs9f0tQY",
    embed_url: "https://www.youtube-nocookie.com/embed/wI2vs9f0tQY",
    thumbnail_url: "https://img.youtube.com/vi/wI2vs9f0tQY/hqdefault.jpg",
    duration: "18:15",
    duration_seconds: 1095,
    channel_name: "Mizko",
    description: "Mapping conversion funnels, decision trees, hierarchy branches, and frictionless navigation pathways.",
    sequence_no: 3,
    created_at: "2026-08-20 16:46:00",
    updated_at: "2026-08-20 16:46:00"
  },
  // Module 105-3
  {
    video_id: "vid-105-3-1",
    module_id: "mod-105-3",
    course_id: "crs-105",
    title: "Typography Rules for UI Design",
    youtube_video_id: "a5KYlHNKQB8",
    youtube_url: "https://www.youtube.com/watch?v=a5KYlHNKQB8",
    embed_url: "https://www.youtube-nocookie.com/embed/a5KYlHNKQB8",
    thumbnail_url: "https://img.youtube.com/vi/a5KYlHNKQB8/hqdefault.jpg",
    duration: "22:30",
    duration_seconds: 1350,
    channel_name: "The Futur",
    description: "Font pairing, optical sizes, modular scales (Major Second, Perfect Fourth), line-height, and legibility ratios.",
    sequence_no: 1,
    created_at: "2026-08-20 16:52:00",
    updated_at: "2026-08-20 16:52:00"
  },
  {
    video_id: "vid-105-3-2",
    module_id: "mod-105-3",
    course_id: "crs-105",
    title: "Color Theory & Creating Palettes for UI Systems",
    youtube_video_id: "rMclmsf3aQ4",
    youtube_url: "https://www.youtube.com/watch?v=rMclmsf3aQ4",
    embed_url: "https://www.youtube-nocookie.com/embed/rMclmsf3aQ4",
    thumbnail_url: "https://img.youtube.com/vi/rMclmsf3aQ4/hqdefault.jpg",
    duration: "19:40",
    duration_seconds: 1180,
    channel_name: "Flux Academy",
    description: "Harmonious palettes, HSL color space, accessible contrast ratios for text, and semantic state indicators.",
    sequence_no: 2,
    created_at: "2026-08-20 16:54:00",
    updated_at: "2026-08-20 16:54:00"
  },
  {
    video_id: "vid-105-3-3",
    module_id: "mod-105-3",
    course_id: "crs-105",
    title: "Visual Hierarchy Principles in Digital Products",
    youtube_video_id: "9ptm_bA2Hio",
    youtube_url: "https://www.youtube.com/watch?v=9ptm_bA2Hio",
    embed_url: "https://www.youtube-nocookie.com/embed/9ptm_bA2Hio",
    thumbnail_url: "https://img.youtube.com/vi/9ptm_bA2Hio/hqdefault.jpg",
    duration: "16:50",
    duration_seconds: 1010,
    channel_name: "Satori Graphics",
    description: "Scale, contrast, whitespace, proximity, and visual focal points that guide user attention effectively.",
    sequence_no: 3,
    created_at: "2026-08-20 16:56:00",
    updated_at: "2026-08-20 16:56:00"
  },
  // Module 105-4
  {
    video_id: "vid-105-4-1",
    module_id: "mod-105-4",
    course_id: "crs-105",
    title: "Design Systems in Figma - Components, Variants & Auto-layout",
    youtube_video_id: "k74NY9OQnHM",
    youtube_url: "https://www.youtube.com/watch?v=k74NY9OQnHM",
    embed_url: "https://www.youtube-nocookie.com/embed/k74NY9OQnHM",
    thumbnail_url: "https://img.youtube.com/vi/k74NY9OQnHM/hqdefault.jpg",
    duration: "01:45:10",
    duration_seconds: 6310,
    channel_name: "freeCodeCamp.org",
    description: "Constructing robust UI component libraries, nested components, interactive component states, and property props.",
    sequence_no: 1,
    created_at: "2026-08-20 17:02:00",
    updated_at: "2026-08-20 17:02:00"
  },
  {
    video_id: "vid-105-4-2",
    module_id: "mod-105-4",
    course_id: "crs-105",
    title: "Design Tokens in 100 Seconds",
    youtube_video_id: "2g8qZ_f7_2M",
    youtube_url: "https://www.youtube.com/watch?v=2g8qZ_f7_2M",
    embed_url: "https://www.youtube-nocookie.com/embed/2g8qZ_f7_2M",
    thumbnail_url: "https://img.youtube.com/vi/2g8qZ_f7_2M/hqdefault.jpg",
    duration: "02:15",
    duration_seconds: 135,
    channel_name: "DesignCourse",
    description: "Platform-agnostic design tokens: colors, spacing, typography mapped seamlessly from Figma to Tailwind/CSS variables.",
    sequence_no: 2,
    created_at: "2026-08-20 17:04:00",
    updated_at: "2026-08-20 17:04:00"
  },
  {
    video_id: "vid-105-4-3",
    module_id: "mod-105-4",
    course_id: "crs-105",
    title: "Atomic Design Methodology in Enterprise Applications",
    youtube_video_id: "pW2yD_R3WqE",
    youtube_url: "https://www.youtube.com/watch?v=pW2yD_R3WqE",
    embed_url: "https://www.youtube-nocookie.com/embed/pW2yD_R3WqE",
    thumbnail_url: "https://img.youtube.com/vi/pW2yD_R3WqE/hqdefault.jpg",
    duration: "25:20",
    duration_seconds: 1520,
    channel_name: "Brad Frost",
    description: "Atoms, molecules, organisms, templates, and pages: organizing design libraries for modular engineering reuse.",
    sequence_no: 3,
    created_at: "2026-08-20 17:06:00",
    updated_at: "2026-08-20 17:06:00"
  },
  // Module 105-5
  {
    video_id: "vid-105-5-1",
    module_id: "mod-105-5",
    course_id: "crs-105",
    title: "Web Accessibility (WCAG) Full Course",
    youtube_video_id: "20SHvU2PKsM",
    youtube_url: "https://www.youtube.com/watch?v=20SHvU2PKsM",
    embed_url: "https://www.youtube-nocookie.com/embed/20SHvU2PKsM",
    thumbnail_url: "https://img.youtube.com/vi/20SHvU2PKsM/hqdefault.jpg",
    duration: "01:30:20",
    duration_seconds: 5420,
    channel_name: "freeCodeCamp.org",
    description: "WCAG 2.2 principles: Perceivable, Operable, Understandable, Robust, keyboard navigation, and ARIA roles.",
    sequence_no: 1,
    created_at: "2026-08-20 17:12:00",
    updated_at: "2026-08-20 17:12:00"
  },
  {
    video_id: "vid-105-5-2",
    module_id: "mod-105-5",
    course_id: "crs-105",
    title: "Designing for Accessibility in Figma",
    youtube_video_id: "z8xUCzToFQ8",
    youtube_url: "https://www.youtube.com/watch?v=z8xUCzToFQ8",
    embed_url: "https://www.youtube-nocookie.com/embed/z8xUCzToFQ8",
    thumbnail_url: "https://img.youtube.com/vi/z8xUCzToFQ8/hqdefault.jpg",
    duration: "24:10",
    duration_seconds: 1450,
    channel_name: "Figma",
    description: "Using plugins to evaluate contrast, focus order, accessible touch targets, and color blindness simulation.",
    sequence_no: 2,
    created_at: "2026-08-20 17:14:00",
    updated_at: "2026-08-20 17:14:00"
  },
  {
    video_id: "vid-105-5-3",
    module_id: "mod-105-5",
    course_id: "crs-105",
    title: "Designer to Developer Handoff Best Practices",
    youtube_video_id: "G8v1s19V2wM",
    youtube_url: "https://www.youtube.com/watch?v=G8v1s19V2wM",
    embed_url: "https://www.youtube-nocookie.com/embed/G8v1s19V2wM",
    thumbnail_url: "https://img.youtube.com/vi/G8v1s19V2wM/hqdefault.jpg",
    duration: "18:40",
    duration_seconds: 1120,
    channel_name: "Jesse Showalter",
    description: "Writing clear spec notes, redlining responsive behavior, exporting assets cleanly, and code inspect mode in Figma.",
    sequence_no: 3,
    created_at: "2026-08-20 17:16:00",
    updated_at: "2026-08-20 17:16:00"
  },
  // ===================================================================
  // COURSE 6: crs-106 (Special Topics Seminar - Elective Only)
  // ===================================================================
  // Module 106-1
  {
    video_id: "vid-106-1-1",
    module_id: "mod-106-1",
    course_id: "crs-106",
    title: "How to Read an Academic Research Paper Effectively",
    youtube_video_id: "qY_hE4BvU2Q",
    youtube_url: "https://www.youtube.com/watch?v=qY_hE4BvU2Q",
    embed_url: "https://www.youtube-nocookie.com/embed/qY_hE4BvU2Q",
    thumbnail_url: "https://img.youtube.com/vi/qY_hE4BvU2Q/hqdefault.jpg",
    duration: "15:20",
    duration_seconds: 920,
    channel_name: "Stanford University",
    description: "Three-pass approach to reading scholarly papers: abstract skimming, methodology evaluation, and in-depth scrutiny.",
    sequence_no: 1,
    created_at: "2026-09-01 08:12:00",
    updated_at: "2026-09-01 08:12:00"
  },
  {
    video_id: "vid-106-1-2",
    module_id: "mod-106-1",
    course_id: "crs-106",
    title: "Critical Thinking & Logical Fallacies in Academic Debate",
    youtube_video_id: "43xW9hE70g0",
    youtube_url: "https://www.youtube.com/watch?v=43xW9hE70g0",
    embed_url: "https://www.youtube-nocookie.com/embed/43xW9hE70g0",
    thumbnail_url: "https://img.youtube.com/vi/43xW9hE70g0/hqdefault.jpg",
    duration: "21:10",
    duration_seconds: 1270,
    channel_name: "CrashCourse",
    description: "Recognizing inductive and deductive fallacies, ad hominem attacks, straw man arguments, and empirical confirmation bias.",
    sequence_no: 2,
    created_at: "2026-09-01 08:14:00",
    updated_at: "2026-09-01 08:14:00"
  },
  {
    video_id: "vid-106-1-3",
    module_id: "mod-106-1",
    course_id: "crs-106",
    title: "Literature Review Process & Synthesis Matrices",
    youtube_video_id: "9r_yQ4f2jQ4",
    youtube_url: "https://www.youtube.com/watch?v=9r_yQ4f2jQ4",
    embed_url: "https://www.youtube-nocookie.com/embed/9r_yQ4f2jQ4",
    thumbnail_url: "https://img.youtube.com/vi/9r_yQ4f2jQ4/hqdefault.jpg",
    duration: "28:40",
    duration_seconds: 1720,
    channel_name: "Grad Coach",
    description: "Aggregating scholarly sources, synthesizing findings across authors, identifying research gaps, and proper citation.",
    sequence_no: 3,
    created_at: "2026-09-01 08:16:00",
    updated_at: "2026-09-01 08:16:00"
  },
  // Module 106-2
  {
    video_id: "vid-106-2-1",
    module_id: "mod-106-2",
    course_id: "crs-106",
    title: "How to Speak - Patrick Winston Masterclass",
    youtube_video_id: "Unzc731iCUY",
    youtube_url: "https://www.youtube.com/watch?v=Unzc731iCUY",
    embed_url: "https://www.youtube-nocookie.com/embed/Unzc731iCUY",
    thumbnail_url: "https://img.youtube.com/vi/Unzc731iCUY/hqdefault.jpg",
    duration: "01:03:20",
    duration_seconds: 3800,
    channel_name: "MIT OpenCourseWare",
    description: "Renowned MIT lecture on effective academic and scientific communication, rhetoric, slide rules, and engaging audiences.",
    sequence_no: 1,
    created_at: "2026-09-01 08:22:00",
    updated_at: "2026-09-01 08:22:00"
  },
  {
    video_id: "vid-106-2-2",
    module_id: "mod-106-2",
    course_id: "crs-106",
    title: "Technical Writing Essentials for Engineers",
    youtube_video_id: "7152-Q_f2tM",
    youtube_url: "https://www.youtube.com/watch?v=7152-Q_f2tM",
    embed_url: "https://www.youtube-nocookie.com/embed/7152-Q_f2tM",
    thumbnail_url: "https://img.youtube.com/vi/7152-Q_f2tM/hqdefault.jpg",
    duration: "32:15",
    duration_seconds: 1935,
    channel_name: "Google Open Source",
    description: "Clarity, precision, active voice, bulleted documentation, and avoiding ambiguity in technical specifications.",
    sequence_no: 2,
    created_at: "2026-09-01 08:24:00",
    updated_at: "2026-09-01 08:24:00"
  },
  {
    video_id: "vid-106-2-3",
    module_id: "mod-106-2",
    course_id: "crs-106",
    title: "Presenting Scientific & Technical Findings Clearly",
    youtube_video_id: "v_24W_1x7kM",
    youtube_url: "https://www.youtube.com/watch?v=v_24W_1x7kM",
    embed_url: "https://www.youtube-nocookie.com/embed/v_24W_1x7kM",
    thumbnail_url: "https://img.youtube.com/vi/v_24W_1x7kM/hqdefault.jpg",
    duration: "19:40",
    duration_seconds: 1180,
    channel_name: "Nature",
    description: "Storytelling in scientific talks, visualizing quantitative evidence accurately, and fielding audience Q&A questions.",
    sequence_no: 3,
    created_at: "2026-09-01 08:26:00",
    updated_at: "2026-09-01 08:26:00"
  },
  // Module 106-3
  {
    video_id: "vid-106-3-1",
    module_id: "mod-106-3",
    course_id: "crs-106",
    title: "AI Ethics: Algorithmic Bias, Fairness & Accountability",
    youtube_video_id: "b6v_t8E9Q1k",
    youtube_url: "https://www.youtube.com/watch?v=b6v_t8E9Q1k",
    embed_url: "https://www.youtube-nocookie.com/embed/b6v_t8E9Q1k",
    thumbnail_url: "https://img.youtube.com/vi/b6v_t8E9Q1k/hqdefault.jpg",
    duration: "38:20",
    duration_seconds: 2300,
    channel_name: "MIT CSAIL",
    description: "Historical biases in training datasets, disparate impact in automated systems, and algorithmic auditing methodologies.",
    sequence_no: 1,
    created_at: "2026-09-01 08:32:00",
    updated_at: "2026-09-01 08:32:00"
  },
  {
    video_id: "vid-106-3-2",
    module_id: "mod-106-3",
    course_id: "crs-106",
    title: "Responsible AI Principles in Practice",
    youtube_video_id: "z_4g7_2w8jM",
    youtube_url: "https://www.youtube.com/watch?v=z_4g7_2w8jM",
    embed_url: "https://www.youtube-nocookie.com/embed/z_4g7_2w8jM",
    thumbnail_url: "https://img.youtube.com/vi/z_4g7_2w8jM/hqdefault.jpg",
    duration: "24:50",
    duration_seconds: 1490,
    channel_name: "Google Cloud Tech",
    description: "Implementing explainability, safety rails, privacy-preserving machine learning, and human-in-the-loop oversight.",
    sequence_no: 2,
    created_at: "2026-09-01 08:34:00",
    updated_at: "2026-09-01 08:34:00"
  },
  {
    video_id: "vid-106-3-3",
    module_id: "mod-106-3",
    course_id: "crs-106",
    title: "Data Privacy, Surveillance & Digital Ethics",
    youtube_video_id: "2Q88p4bK_yY",
    youtube_url: "https://www.youtube.com/watch?v=2Q88p4bK_yY",
    embed_url: "https://www.youtube-nocookie.com/embed/2Q88p4bK_yY",
    thumbnail_url: "https://img.youtube.com/vi/2Q88p4bK_yY/hqdefault.jpg",
    duration: "29:10",
    duration_seconds: 1750,
    channel_name: "Harvard Berkman Klein",
    description: "GDPR principles, informed user consent, differential privacy, and ethical dilemmas in large-scale data harvesting.",
    sequence_no: 3,
    created_at: "2026-09-01 08:36:00",
    updated_at: "2026-09-01 08:36:00"
  },
  // Module 106-4
  {
    video_id: "vid-106-4-1",
    module_id: "mod-106-4",
    course_id: "crs-106",
    title: "Open Source Software Licensing Explained (MIT, Apache, GPL)",
    youtube_video_id: "GbqD1t6k2eQ",
    youtube_url: "https://www.youtube.com/watch?v=GbqD1t6k2eQ",
    embed_url: "https://www.youtube-nocookie.com/embed/GbqD1t6k2eQ",
    thumbnail_url: "https://img.youtube.com/vi/GbqD1t6k2eQ/hqdefault.jpg",
    duration: "18:30",
    duration_seconds: 1110,
    channel_name: "TechWorld with Nana",
    description: "Permissive versus copyleft licenses, patent grant clauses, dual-licensing models, and intellectual property obligations.",
    sequence_no: 1,
    created_at: "2026-09-01 08:42:00",
    updated_at: "2026-09-01 08:42:00"
  },
  {
    video_id: "vid-106-4-2",
    module_id: "mod-106-4",
    course_id: "crs-106",
    title: "Git & GitHub for Collaborative Development",
    youtube_video_id: "RGOj5yH7evk",
    youtube_url: "https://www.youtube.com/watch?v=RGOj5yH7evk",
    embed_url: "https://www.youtube-nocookie.com/embed/RGOj5yH7evk",
    thumbnail_url: "https://img.youtube.com/vi/RGOj5yH7evk/hqdefault.jpg",
    duration: "01:10:45",
    duration_seconds: 4245,
    channel_name: "freeCodeCamp.org",
    description: "Forking, pull requests, code reviews, semantic commit standards, merge conflict resolution, and release tagging.",
    sequence_no: 2,
    created_at: "2026-09-01 08:44:00",
    updated_at: "2026-09-01 08:44:00"
  },
  {
    video_id: "vid-106-4-3",
    module_id: "mod-106-4",
    course_id: "crs-106",
    title: "Community Governance in Open Source Ecosystems",
    youtube_video_id: "v81q9_R2M8I",
    youtube_url: "https://www.youtube.com/watch?v=v81q9_R2M8I",
    embed_url: "https://www.youtube-nocookie.com/embed/v81q9_R2M8I",
    thumbnail_url: "https://img.youtube.com/vi/v81q9_R2M8I/hqdefault.jpg",
    duration: "26:15",
    duration_seconds: 1575,
    channel_name: "Linux Foundation",
    description: "Benevolent Dictator models vs Steering Committees, RFC decision processes, Codes of Conduct, and project sustainability.",
    sequence_no: 3,
    created_at: "2026-09-01 08:46:00",
    updated_at: "2026-09-01 08:46:00"
  },
  // Module 106-5
  {
    video_id: "vid-106-5-1",
    module_id: "mod-106-5",
    course_id: "crs-106",
    title: "The Academic Peer Review Process Explained",
    youtube_video_id: "p_94fK7_2b0",
    youtube_url: "https://www.youtube.com/watch?v=p_94fK7_2b0",
    embed_url: "https://www.youtube-nocookie.com/embed/p_94fK7_2b0",
    thumbnail_url: "https://img.youtube.com/vi/p_94fK7_2b0/hqdefault.jpg",
    duration: "16:40",
    duration_seconds: 1e3,
    channel_name: "Wiley Researcher Academy",
    description: "Single-blind, double-blind, and open review systems, editorial triage, reviewer critiques, and revision letters.",
    sequence_no: 1,
    created_at: "2026-09-01 08:52:00",
    updated_at: "2026-09-01 08:52:00"
  },
  {
    video_id: "vid-106-5-2",
    module_id: "mod-106-5",
    course_id: "crs-106",
    title: "Preparing for Your Thesis & Capstone Defense",
    youtube_video_id: "7x29q_1B5sU",
    youtube_url: "https://www.youtube.com/watch?v=7x29q_1B5sU",
    embed_url: "https://www.youtube-nocookie.com/embed/7x29q_1B5sU",
    thumbnail_url: "https://img.youtube.com/vi/7x29q_1B5sU/hqdefault.jpg",
    duration: "22:50",
    duration_seconds: 1370,
    channel_name: "Oxford Academic",
    description: "Structuring the defense presentation, anticipating committee critiques, handling limitations with intellectual honesty.",
    sequence_no: 2,
    created_at: "2026-09-01 08:54:00",
    updated_at: "2026-09-01 08:54:00"
  },
  {
    video_id: "vid-106-5-3",
    module_id: "mod-106-5",
    course_id: "crs-106",
    title: "The Reproducibility Crisis in Science and Computing",
    youtube_video_id: "3Qf9g_0v6uE",
    youtube_url: "https://www.youtube.com/watch?v=3Qf9g_0v6uE",
    embed_url: "https://www.youtube-nocookie.com/embed/3Qf9g_0v6uE",
    thumbnail_url: "https://img.youtube.com/vi/3Qf9g_0v6uE/hqdefault.jpg",
    duration: "19:25",
    duration_seconds: 1165,
    channel_name: "Veritasium",
    description: "P-hacking, publication bias towards positive outcomes, replication failures, and containerized computational benchmarks.",
    sequence_no: 3,
    created_at: "2026-09-01 08:56:00",
    updated_at: "2026-09-01 08:56:00"
  },
  // ===================================================================
  // COURSE 7: crs-107 (Upcoming Quantum Computing Primer)
  // ===================================================================
  // Module 107-1
  {
    video_id: "vid-107-1-1",
    module_id: "mod-107-1",
    course_id: "crs-107",
    title: "Essence of Linear Algebra: Vectors, Span & Transformations",
    youtube_video_id: "fNk_zzaMoSs",
    youtube_url: "https://www.youtube.com/watch?v=fNk_zzaMoSs",
    embed_url: "https://www.youtube-nocookie.com/embed/fNk_zzaMoSs",
    thumbnail_url: "https://img.youtube.com/vi/fNk_zzaMoSs/hqdefault.jpg",
    duration: "15:20",
    duration_seconds: 920,
    channel_name: "3Blue1Brown",
    description: "Visual geometric foundations: coordinate spaces, vector addition, linear combinations, and spanning subspaces.",
    sequence_no: 1,
    created_at: "2026-09-10 12:12:00",
    updated_at: "2026-09-10 12:12:00"
  },
  {
    video_id: "vid-107-1-2",
    module_id: "mod-107-1",
    course_id: "crs-107",
    title: "Complex Vector Spaces for Quantum Computing",
    youtube_video_id: "J7DY3hGwtWU",
    youtube_url: "https://www.youtube.com/watch?v=J7DY3hGwtWU",
    embed_url: "https://www.youtube-nocookie.com/embed/J7DY3hGwtWU",
    thumbnail_url: "https://img.youtube.com/vi/J7DY3hGwtWU/hqdefault.jpg",
    duration: "28:40",
    duration_seconds: 1720,
    channel_name: "Qiskit / IBM",
    description: "Complex numbers in quantum mechanics, bra-ket Dirac notation, inner products, norms, and orthogonality.",
    sequence_no: 2,
    created_at: "2026-09-10 12:14:00",
    updated_at: "2026-09-10 12:14:00"
  },
  {
    video_id: "vid-107-1-3",
    module_id: "mod-107-1",
    course_id: "crs-107",
    title: "Eigenvectors and Eigenvalues Explained Visually",
    youtube_video_id: "PFDu9oVAE-g",
    youtube_url: "https://www.youtube.com/watch?v=PFDu9oVAE-g",
    embed_url: "https://www.youtube-nocookie.com/embed/PFDu9oVAE-g",
    thumbnail_url: "https://img.youtube.com/vi/PFDu9oVAE-g/hqdefault.jpg",
    duration: "17:15",
    duration_seconds: 1035,
    channel_name: "3Blue1Brown",
    description: "Characteristic polynomials, invariant axes, eigenvalues as stretch factors, and diagonalizing Hermitian operators.",
    sequence_no: 3,
    created_at: "2026-09-10 12:16:00",
    updated_at: "2026-09-10 12:16:00"
  },
  // Module 107-2
  {
    video_id: "vid-107-2-1",
    module_id: "mod-107-2",
    course_id: "crs-107",
    title: "Quantum Computing in 100 Seconds",
    youtube_video_id: "JhHMJCUmq28",
    youtube_url: "https://www.youtube.com/watch?v=JhHMJCUmq28",
    embed_url: "https://www.youtube-nocookie.com/embed/JhHMJCUmq28",
    thumbnail_url: "https://img.youtube.com/vi/JhHMJCUmq28/hqdefault.jpg",
    duration: "02:20",
    duration_seconds: 140,
    channel_name: "Fireship",
    description: "Rapid introduction to qubits, superposition of states, quantum entanglement, and exponential state scaling.",
    sequence_no: 1,
    created_at: "2026-09-10 12:22:00",
    updated_at: "2026-09-10 12:22:00"
  },
  {
    video_id: "vid-107-2-2",
    module_id: "mod-107-2",
    course_id: "crs-107",
    title: "Quantum Computing Expert Explains in 5 Levels of Difficulty",
    youtube_video_id: "F_Riqjdh2oM",
    youtube_url: "https://www.youtube.com/watch?v=F_Riqjdh2oM",
    embed_url: "https://www.youtube-nocookie.com/embed/F_Riqjdh2oM",
    thumbnail_url: "https://img.youtube.com/vi/F_Riqjdh2oM/hqdefault.jpg",
    duration: "23:45",
    duration_seconds: 1425,
    channel_name: "WIRED",
    description: "Explaining quantum physics and computation from a child level to high school, undergraduate, graduate, and researcher.",
    sequence_no: 2,
    created_at: "2026-09-10 12:24:00",
    updated_at: "2026-09-10 12:24:00"
  },
  {
    video_id: "vid-107-2-3",
    module_id: "mod-107-2",
    course_id: "crs-107",
    title: "Superposition, Measurement & The Bloch Sphere",
    youtube_video_id: "7q_yQ4e3bQ1",
    youtube_url: "https://www.youtube.com/watch?v=7q_yQ4e3bQ1",
    embed_url: "https://www.youtube-nocookie.com/embed/7q_yQ4e3bQ1",
    thumbnail_url: "https://img.youtube.com/vi/7q_yQ4e3bQ1/hqdefault.jpg",
    duration: "32:10",
    duration_seconds: 1930,
    channel_name: "IBM Technology",
    description: "Bloch sphere angles theta and phi, projection probabilities |alpha|^2 and |beta|^2, and wavefunction collapse.",
    sequence_no: 3,
    created_at: "2026-09-10 12:26:00",
    updated_at: "2026-09-10 12:26:00"
  },
  // Module 107-3
  {
    video_id: "vid-107-3-1",
    module_id: "mod-107-3",
    course_id: "crs-107",
    title: "Single and Multi-Qubit Quantum Logic Gates",
    youtube_video_id: "L_4hXQ6a9v0",
    youtube_url: "https://www.youtube.com/watch?v=L_4hXQ6a9v0",
    embed_url: "https://www.youtube-nocookie.com/embed/L_4hXQ6a9v0",
    thumbnail_url: "https://img.youtube.com/vi/L_4hXQ6a9v0/hqdefault.jpg",
    duration: "36:40",
    duration_seconds: 2200,
    channel_name: "Qiskit / IBM",
    description: "Pauli matrices X, Y, Z, Phase gate S, T gate, Hadamard gate H, and controlled operations (CNOT, CZ).",
    sequence_no: 1,
    created_at: "2026-09-10 12:32:00",
    updated_at: "2026-09-10 12:32:00"
  },
  {
    video_id: "vid-107-3-2",
    module_id: "mod-107-3",
    course_id: "crs-107",
    title: "Quantum Circuits & Entanglement with Bell States",
    youtube_video_id: "8wY9f2k0sQ4",
    youtube_url: "https://www.youtube.com/watch?v=8wY9f2k0sQ4",
    embed_url: "https://www.youtube-nocookie.com/embed/8wY9f2k0sQ4",
    thumbnail_url: "https://img.youtube.com/vi/8wY9f2k0sQ4/hqdefault.jpg",
    duration: "27:15",
    duration_seconds: 1635,
    channel_name: "Microsoft Quantum",
    description: "Generating maximally entangled Bell states (|00> + |11>)/sqrt(2) using Hadamard and CNOT gates in circuit diagrams.",
    sequence_no: 2,
    created_at: "2026-09-10 12:34:00",
    updated_at: "2026-09-10 12:34:00"
  },
  {
    video_id: "vid-107-3-3",
    module_id: "mod-107-3",
    course_id: "crs-107",
    title: "Reversibility & Phase Kickback in Quantum Circuits",
    youtube_video_id: "7v_1x9P3k2A",
    youtube_url: "https://www.youtube.com/watch?v=7v_1x9P3k2A",
    embed_url: "https://www.youtube-nocookie.com/embed/7v_1x9P3k2A",
    thumbnail_url: "https://img.youtube.com/vi/7v_1x9P3k2A/hqdefault.jpg",
    duration: "21:50",
    duration_seconds: 1310,
    channel_name: "MIT OpenCourseWare",
    description: "Unitary gate reversibility U * U_dagger = I, ancilla qubits, and phase kickback mechanisms used in quantum oracles.",
    sequence_no: 3,
    created_at: "2026-09-10 12:36:00",
    updated_at: "2026-09-10 12:36:00"
  },
  // Module 107-4
  {
    video_id: "vid-107-4-1",
    module_id: "mod-107-4",
    course_id: "crs-107",
    title: "Shor's Algorithm: Quantum Computing vs RSA Cryptography",
    youtube_video_id: "w2x7g3v0m9A",
    youtube_url: "https://www.youtube.com/watch?v=w2x7g3v0m9A",
    embed_url: "https://www.youtube-nocookie.com/embed/w2x7g3v0m9A",
    thumbnail_url: "https://img.youtube.com/vi/w2x7g3v0m9A/hqdefault.jpg",
    duration: "24:10",
    duration_seconds: 1450,
    channel_name: "Veritasium",
    description: "How quantum Fourier transform finds the modular period of prime factors in polynomial time, breaking asymmetric RSA.",
    sequence_no: 1,
    created_at: "2026-09-10 12:42:00",
    updated_at: "2026-09-10 12:42:00"
  },
  {
    video_id: "vid-107-4-2",
    module_id: "mod-107-4",
    course_id: "crs-107",
    title: "Grover's Quantum Search Algorithm Explained",
    youtube_video_id: "Y728_1aQ8bI",
    youtube_url: "https://www.youtube.com/watch?v=Y728_1aQ8bI",
    embed_url: "https://www.youtube-nocookie.com/embed/Y728_1aQ8bI",
    thumbnail_url: "https://img.youtube.com/vi/Y728_1aQ8bI/hqdefault.jpg",
    duration: "31:20",
    duration_seconds: 1880,
    channel_name: "Qiskit / IBM",
    description: "Unstructured database search speedup from O(N) to O(sqrt(N)) via oracle phase inversion and diffusion operator.",
    sequence_no: 2,
    created_at: "2026-09-10 12:44:00",
    updated_at: "2026-09-10 12:44:00"
  },
  {
    video_id: "vid-107-4-3",
    module_id: "mod-107-4",
    course_id: "crs-107",
    title: "Deutsch-Jozsa Algorithm & Quantum Parallelism",
    youtube_video_id: "4v_1w8e3x0k",
    youtube_url: "https://www.youtube.com/watch?v=4v_1w8e3x0k",
    embed_url: "https://www.youtube-nocookie.com/embed/4v_1w8e3x0k",
    thumbnail_url: "https://img.youtube.com/vi/4v_1w8e3x0k/hqdefault.jpg",
    duration: "22:40",
    duration_seconds: 1360,
    channel_name: "Oxford Quantum",
    description: "Determining if a boolean function is constant or balanced in a single quantum evaluation versus 2^(n-1)+1 classical queries.",
    sequence_no: 3,
    created_at: "2026-09-10 12:46:00",
    updated_at: "2026-09-10 12:46:00"
  },
  // Module 107-5
  {
    video_id: "vid-107-5-1",
    module_id: "mod-107-5",
    course_id: "crs-107",
    title: "Writing Quantum Code with Python & Qiskit",
    youtube_video_id: "a1NZC5ETQD8",
    youtube_url: "https://www.youtube.com/watch?v=a1NZC5ETQD8",
    embed_url: "https://www.youtube-nocookie.com/embed/a1NZC5ETQD8",
    thumbnail_url: "https://img.youtube.com/vi/a1NZC5ETQD8/hqdefault.jpg",
    duration: "29:30",
    duration_seconds: 1770,
    channel_name: "IBM Technology",
    description: "Constructing QuantumCircuit objects in Python, applying quantum gates, simulating with Aer, and measuring bitstrings.",
    sequence_no: 1,
    created_at: "2026-09-10 12:52:00",
    updated_at: "2026-09-10 12:52:00"
  },
  {
    video_id: "vid-107-5-2",
    module_id: "mod-107-5",
    course_id: "crs-107",
    title: "How Superconducting Quantum Computers Are Physically Built",
    youtube_video_id: "y_3fQ8v0x1A",
    youtube_url: "https://www.youtube.com/watch?v=y_3fQ8v0x1A",
    embed_url: "https://www.youtube-nocookie.com/embed/y_3fQ8v0x1A",
    thumbnail_url: "https://img.youtube.com/vi/y_3fQ8v0x1A/hqdefault.jpg",
    duration: "21:15",
    duration_seconds: 1275,
    channel_name: "IBM Technology",
    description: "Josephson junctions, transmon qubits, dilution refrigerators at 15 millikelvin, microwave control lines, and cryogenics.",
    sequence_no: 2,
    created_at: "2026-09-10 12:54:00",
    updated_at: "2026-09-10 12:54:00"
  },
  {
    video_id: "vid-107-5-3",
    module_id: "mod-107-5",
    course_id: "crs-107",
    title: "Quantum Error Correction & Fault-Tolerant Architectures",
    youtube_video_id: "6q98_v1x3b0",
    youtube_url: "https://www.youtube.com/watch?v=6q98_v1x3b0",
    embed_url: "https://www.youtube-nocookie.com/embed/6q98_v1x3b0",
    thumbnail_url: "https://img.youtube.com/vi/6q98_v1x3b0/hqdefault.jpg",
    duration: "26:50",
    duration_seconds: 1610,
    channel_name: "QuTech Academy",
    description: "No-cloning theorem, syndrome measurements, bit-flip/phase-flip detection, surface codes, and logical qubit thresholds.",
    sequence_no: 3,
    created_at: "2026-09-10 12:56:00",
    updated_at: "2026-09-10 12:56:00"
  }
];

// backend/src/services/searchService.ts
function sanitizeSearchQuery(input) {
  if (typeof input !== "string") return "";
  return input.trim().slice(0, 100).replace(/[\x00-\x1F\x7F]/g, "");
}
function searchCourses(courses, query) {
  const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
  if (!cleanQuery) return courses;
  return courses.filter((c) => {
    const nameMatch = c.course_name.toLowerCase().includes(cleanQuery);
    const categoryMatch = c.category.toLowerCase().includes(cleanQuery);
    const idMatch = c.course_id.toLowerCase().includes(cleanQuery);
    return nameMatch || categoryMatch || idMatch;
  });
}
function searchLearners(learners, query) {
  const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
  if (!cleanQuery) return learners;
  return learners.filter((l) => {
    const nameMatch = l.display_name.toLowerCase().includes(cleanQuery);
    const rollMatch = l.roll_no ? l.roll_no.toLowerCase().includes(cleanQuery) : false;
    const idMatch = l.learner_id.toLowerCase().includes(cleanQuery);
    return nameMatch || rollMatch || idMatch;
  });
}
function searchEnrollments(enrollments, coursesMap, learnersMap, query) {
  const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
  if (!cleanQuery) return enrollments;
  return enrollments.filter((e) => {
    const idMatch = e.enrollment_id.toLowerCase().includes(cleanQuery);
    const learner = learnersMap.get(e.learner_id);
    const course = coursesMap.get(e.course_id);
    const learnerNameMatch = learner ? learner.display_name.toLowerCase().includes(cleanQuery) : false;
    const rollNoMatch = learner?.roll_no ? learner.roll_no.toLowerCase().includes(cleanQuery) : false;
    const learnerIdMatch = e.learner_id.toLowerCase().includes(cleanQuery);
    const courseNameMatch = course ? course.course_name.toLowerCase().includes(cleanQuery) : false;
    const courseIdMatch = e.course_id.toLowerCase().includes(cleanQuery);
    return idMatch || learnerNameMatch || rollNoMatch || learnerIdMatch || courseNameMatch || courseIdMatch;
  });
}
function searchActivities(activities, query) {
  const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
  if (!cleanQuery) return activities;
  return activities.filter((a) => {
    const rawType = a.activity_type.toLowerCase();
    const friendlyType = rawType.replace(/_/g, " ");
    const typeMatch = rawType.includes(cleanQuery) || friendlyType.includes(cleanQuery);
    const enrIdMatch = a.enrollment_id.toLowerCase().includes(cleanQuery);
    const actIdMatch = a.activity_id.toLowerCase().includes(cleanQuery);
    return typeMatch || enrIdMatch || actIdMatch;
  });
}

// backend/src/repositories/db.ts
var RelationalStore = class {
  constructor() {
    this.courses = /* @__PURE__ */ new Map();
    this.learners = /* @__PURE__ */ new Map();
    this.enrollments = /* @__PURE__ */ new Map();
    this.lessons = /* @__PURE__ */ new Map();
    this.activities = /* @__PURE__ */ new Map();
    this.modules = /* @__PURE__ */ new Map();
    this.videos = /* @__PURE__ */ new Map();
    this.sqliteDb = new DatabaseSync(":memory:");
    this.initSqliteSchema();
    this.seed();
  }
  initSqliteSchema() {
    this.sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS courses (
        course_id TEXT PRIMARY KEY,
        course_name TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS learners (
        learner_id TEXT PRIMARY KEY,
        roll_no TEXT UNIQUE,
        display_name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS lessons (
        lesson_id TEXT PRIMARY KEY,
        course_id TEXT NOT NULL,
        lesson_name TEXT NOT NULL,
        sequence_no INTEGER NOT NULL DEFAULT 1,
        is_required INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        FOREIGN KEY (course_id) REFERENCES courses(course_id)
      );

      CREATE TABLE IF NOT EXISTS enrollments (
        enrollment_id TEXT PRIMARY KEY,
        learner_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'enrolled',
        enrolled_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (learner_id) REFERENCES learners(learner_id),
        FOREIGN KEY (course_id) REFERENCES courses(course_id)
      );

      CREATE TABLE IF NOT EXISTS activities (
        activity_id TEXT PRIMARY KEY,
        enrollment_id TEXT NOT NULL,
        lesson_id TEXT,
        activity_type TEXT NOT NULL,
        activity_date TEXT NOT NULL,
        completed INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id)
      );

      CREATE TABLE IF NOT EXISTS course_modules (
        module_id TEXT PRIMARY KEY,
        course_id TEXT NOT NULL,
        module_name TEXT NOT NULL,
        description TEXT,
        sequence_no INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (course_id) REFERENCES courses(course_id)
      );

      CREATE TABLE IF NOT EXISTS module_videos (
        video_id TEXT PRIMARY KEY,
        module_id TEXT NOT NULL,
        course_id TEXT NOT NULL,
        title TEXT NOT NULL,
        youtube_video_id TEXT NOT NULL,
        youtube_url TEXT NOT NULL,
        embed_url TEXT NOT NULL,
        thumbnail_url TEXT,
        duration TEXT NOT NULL,
        duration_seconds INTEGER NOT NULL DEFAULT 0,
        channel_name TEXT,
        description TEXT,
        sequence_no INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (module_id) REFERENCES course_modules(module_id),
        FOREIGN KEY (course_id) REFERENCES courses(course_id)
      );

      CREATE INDEX IF NOT EXISTS idx_courses_category ON courses(category);
      CREATE INDEX IF NOT EXISTS idx_courses_name ON courses(course_name);
      CREATE INDEX IF NOT EXISTS idx_learners_roll ON learners(roll_no);
      CREATE INDEX IF NOT EXISTS idx_learners_name ON learners(display_name);
      CREATE INDEX IF NOT EXISTS idx_enrollments_status ON enrollments(status);
      CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(activity_type);
      CREATE INDEX IF NOT EXISTS idx_activities_enr ON activities(enrollment_id);
      CREATE INDEX IF NOT EXISTS idx_modules_course ON course_modules(course_id);
      CREATE INDEX IF NOT EXISTS idx_videos_module ON module_videos(module_id);
      CREATE INDEX IF NOT EXISTS idx_videos_course ON module_videos(course_id);
    `);
  }
  seed() {
    this.courses.clear();
    this.learners.clear();
    this.enrollments.clear();
    this.lessons.clear();
    this.activities.clear();
    this.modules.clear();
    this.videos.clear();
    this.sqliteDb.exec(`
      DELETE FROM module_videos;
      DELETE FROM course_modules;
      DELETE FROM activities;
      DELETE FROM enrollments;
      DELETE FROM lessons;
      DELETE FROM learners;
      DELETE FROM courses;
    `);
    const initialCourses = [
      {
        course_id: "crs-101",
        course_name: "Modern Full-Stack Web Development",
        category: "Computer Science",
        description: "Comprehensive React, Node.js, and TypeScript engineering course.",
        created_at: "2026-08-01 09:00:00",
        updated_at: "2026-08-01 09:00:00",
        is_active: true
      },
      {
        course_id: "crs-102",
        course_name: "Practical Data Science & Machine Learning",
        category: "Data & AI",
        description: "Exploratory data analysis, statistical modeling, and ML pipelines.",
        created_at: "2026-08-05 10:30:00",
        updated_at: "2026-08-05 10:30:00",
        is_active: true
      },
      {
        course_id: "crs-103",
        course_name: "Cloud Infrastructure & DevOps Mastery",
        category: "Cloud Architecture",
        description: "Docker, Kubernetes, CI/CD automation, and cloud deployments.",
        created_at: "2026-08-10 11:15:00",
        updated_at: "2026-08-10 11:15:00",
        is_active: true
      },
      {
        course_id: "crs-104",
        course_name: "Applied Cybersecurity & Threat Defense",
        category: "Information Security",
        description: "Network security, ethical hacking fundamentals, and incident response.",
        created_at: "2026-08-15 14:00:00",
        updated_at: "2026-08-15 14:00:00",
        is_active: true
      },
      {
        course_id: "crs-105",
        course_name: "Enterprise UI/UX Design Systems",
        category: "Design & Product",
        description: "Atomic design principles, accessibility standards, and design workflows.",
        created_at: "2026-08-20 16:20:00",
        updated_at: "2026-08-20 16:20:00",
        is_active: true
      },
      {
        course_id: "crs-106",
        course_name: "Special Topics Seminar (Elective Only)",
        category: "General Studies",
        description: "Course with optional elective modules and 0 required lessons to test edge cases.",
        created_at: "2026-09-01 08:00:00",
        updated_at: "2026-09-01 08:00:00",
        is_active: true
      },
      {
        course_id: "crs-107",
        course_name: "Upcoming Quantum Computing Primer",
        category: "Advanced Science",
        description: "Newly scheduled course with zero current enrolments.",
        created_at: "2026-09-10 12:00:00",
        updated_at: "2026-09-10 12:00:00",
        is_active: false
      }
    ];
    const insertCourse = this.sqliteDb.prepare(`
      INSERT INTO courses (course_id, course_name, category, description, created_at, updated_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    initialCourses.forEach((c) => {
      this.courses.set(c.course_id, c);
      insertCourse.run(c.course_id, c.course_name, c.category, c.description || null, c.created_at, c.updated_at, c.is_active ? 1 : 0);
    });
    const initialLessons = [
      { lesson_id: "les-101-1", course_id: "crs-101", lesson_name: "Architecture & TypeScript Fundamentals", sequence_no: 1, is_required: true, created_at: "2026-08-01 09:30:00" },
      { lesson_id: "les-101-2", course_id: "crs-101", lesson_name: "React Component State & Custom Hooks", sequence_no: 2, is_required: true, created_at: "2026-08-01 10:00:00" },
      { lesson_id: "les-101-3", course_id: "crs-101", lesson_name: "Building Express REST APIs & Auth", sequence_no: 3, is_required: true, created_at: "2026-08-01 10:30:00" },
      { lesson_id: "les-101-4", course_id: "crs-101", lesson_name: "Bonus: Performance Profiling Workshop", sequence_no: 4, is_required: false, created_at: "2026-08-01 11:00:00" },
      { lesson_id: "les-102-1", course_id: "crs-102", lesson_name: "Data Wrangling with Pandas & NumPy", sequence_no: 1, is_required: true, created_at: "2026-08-05 11:00:00" },
      { lesson_id: "les-102-2", course_id: "crs-102", lesson_name: "Statistical Testing & Feature Engineering", sequence_no: 2, is_required: true, created_at: "2026-08-05 11:30:00" },
      { lesson_id: "les-102-3", course_id: "crs-102", lesson_name: "Supervised Learning Classification Models", sequence_no: 3, is_required: true, created_at: "2026-08-05 12:00:00" },
      { lesson_id: "les-103-1", course_id: "crs-103", lesson_name: "Containerization with Docker & Multi-stage", sequence_no: 1, is_required: true, created_at: "2026-08-10 12:00:00" },
      { lesson_id: "les-103-2", course_id: "crs-103", lesson_name: "Kubernetes Pods, Services & Deployments", sequence_no: 2, is_required: true, created_at: "2026-08-10 13:00:00" },
      { lesson_id: "les-104-1", course_id: "crs-104", lesson_name: "Network Packet Analysis & WireShark", sequence_no: 1, is_required: true, created_at: "2026-08-15 15:00:00" },
      { lesson_id: "les-104-2", course_id: "crs-104", lesson_name: "OWASP Top 10 Vulnerabilities & Mitigations", sequence_no: 2, is_required: true, created_at: "2026-08-15 15:30:00" },
      { lesson_id: "les-104-3", course_id: "crs-104", lesson_name: "Elective Lab: CTF Challenge Lab", sequence_no: 3, is_required: false, created_at: "2026-08-15 16:00:00" },
      { lesson_id: "les-106-1", course_id: "crs-106", lesson_name: "Optional Guest Lecture Discussion", sequence_no: 1, is_required: false, created_at: "2026-09-01 08:30:00" }
    ];
    const insertLesson = this.sqliteDb.prepare(`
      INSERT INTO lessons (lesson_id, course_id, lesson_name, sequence_no, is_required, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    initialLessons.forEach((l) => {
      this.lessons.set(l.lesson_id, l);
      insertLesson.run(l.lesson_id, l.course_id, l.lesson_name, l.sequence_no, l.is_required ? 1 : 0, l.created_at);
    });
    const initialLearners = [
      { learner_id: "lrn-001", roll_no: "CS2026-001", display_name: "Amina Al-Mansoor", created_at: "2026-08-02 08:30:00", updated_at: "2026-08-02 08:30:00" },
      { learner_id: "lrn-002", roll_no: "CS2026-002", display_name: "Marcus Vance", created_at: "2026-08-02 09:15:00", updated_at: "2026-08-02 09:15:00" },
      { learner_id: "lrn-003", roll_no: "CS2026-003", display_name: "Elena Rostova", created_at: "2026-08-03 10:00:00", updated_at: "2026-08-03 10:00:00" },
      { learner_id: "lrn-004", roll_no: "CS2026-004", display_name: "Devon Bailey", created_at: "2026-08-04 11:20:00", updated_at: "2026-08-04 11:20:00" },
      { learner_id: "lrn-005", roll_no: "CS2026-005", display_name: "Priya Sundaram", created_at: "2026-08-05 13:45:00", updated_at: "2026-08-05 13:45:00" },
      { learner_id: "lrn-006", roll_no: "CS2026-006", display_name: "Liam O Connor", created_at: "2026-08-06 14:10:00", updated_at: "2026-08-06 14:10:00" },
      { learner_id: "lrn-007", roll_no: "CS2026-007", display_name: "Chloe Zhang", created_at: "2026-08-07 15:30:00", updated_at: "2026-08-07 15:30:00" },
      { learner_id: "lrn-008", roll_no: "CS2026-008", display_name: "Tariq Hassan", created_at: "2026-08-08 16:00:00", updated_at: "2026-08-08 16:00:00" }
    ];
    const insertLearner = this.sqliteDb.prepare(`
      INSERT INTO learners (learner_id, roll_no, display_name, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?)
    `);
    initialLearners.forEach((l) => {
      this.learners.set(l.learner_id, l);
      insertLearner.run(l.learner_id, l.roll_no || null, l.display_name, l.created_at, l.updated_at);
    });
    const initialEnrollments = [
      { enrollment_id: "enr-001", learner_id: "lrn-001", course_id: "crs-101", status: "completed", enrolled_at: "2026-08-05 10:00:00", updated_at: "2026-09-23 18:00:00" },
      { enrollment_id: "enr-002", learner_id: "lrn-002", course_id: "crs-101", status: "enrolled", enrolled_at: "2026-08-06 11:00:00", updated_at: "2026-08-06 11:00:00" },
      { enrollment_id: "enr-003", learner_id: "lrn-003", course_id: "crs-101", status: "withdrawn", enrolled_at: "2026-08-07 12:00:00", updated_at: "2026-08-14 12:00:00" },
      { enrollment_id: "enr-004", learner_id: "lrn-004", course_id: "crs-101", status: "completed", enrolled_at: "2026-08-08 14:00:00", updated_at: "2026-09-14 16:30:00" },
      { enrollment_id: "enr-005", learner_id: "lrn-005", course_id: "crs-102", status: "completed", enrolled_at: "2026-08-10 09:00:00", updated_at: "2026-09-28 14:00:00" },
      { enrollment_id: "enr-006", learner_id: "lrn-006", course_id: "crs-102", status: "enrolled", enrolled_at: "2026-08-11 10:00:00", updated_at: "2026-08-11 10:00:00" },
      { enrollment_id: "enr-007", learner_id: "lrn-007", course_id: "crs-102", status: "enrolled", enrolled_at: "2026-08-12 11:00:00", updated_at: "2026-08-12 11:00:00" },
      { enrollment_id: "enr-008", learner_id: "lrn-001", course_id: "crs-103", status: "enrolled", enrolled_at: "2026-08-15 13:00:00", updated_at: "2026-08-15 13:00:00" },
      { enrollment_id: "enr-009", learner_id: "lrn-003", course_id: "crs-103", status: "completed", enrolled_at: "2026-08-16 14:00:00", updated_at: "2026-10-02 16:30:00" },
      { enrollment_id: "enr-010", learner_id: "lrn-005", course_id: "crs-104", status: "enrolled", enrolled_at: "2026-08-18 15:00:00", updated_at: "2026-08-18 15:00:00" },
      { enrollment_id: "enr-011", learner_id: "lrn-008", course_id: "crs-104", status: "cancelled", enrolled_at: "2026-08-20 16:00:00", updated_at: "2026-08-25 16:00:00" },
      { enrollment_id: "enr-012", learner_id: "lrn-002", course_id: "crs-106", status: "enrolled", enrolled_at: "2026-09-02 10:00:00", updated_at: "2026-09-02 10:00:00" }
    ];
    const insertEnrollment = this.sqliteDb.prepare(`
      INSERT INTO enrollments (enrollment_id, learner_id, course_id, status, enrolled_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    initialEnrollments.forEach((e) => {
      this.enrollments.set(e.enrollment_id, e);
      insertEnrollment.run(e.enrollment_id, e.learner_id, e.course_id, e.status, e.enrolled_at, e.updated_at);
    });
    const initialActivities = [
      { activity_id: "act-001", enrollment_id: "enr-001", lesson_id: "les-101-1", activity_type: "lesson_opened", activity_date: "2026-09-15 10:00:00", completed: false, created_at: "2026-09-15 10:00:00" },
      { activity_id: "act-002", enrollment_id: "enr-001", lesson_id: "les-101-1", activity_type: "lesson_completed", activity_date: "2026-09-15 11:30:00", completed: true, created_at: "2026-09-15 11:30:00" },
      { activity_id: "act-003", enrollment_id: "enr-001", lesson_id: "les-101-1", activity_type: "lesson_completed", activity_date: "2026-09-15 11:35:00", completed: true, created_at: "2026-09-15 11:35:00" },
      // duplicate to test dedup
      { activity_id: "act-004", enrollment_id: "enr-001", lesson_id: "les-101-2", activity_type: "lesson_started", activity_date: "2026-09-18 14:00:00", completed: false, created_at: "2026-09-18 14:00:00" },
      { activity_id: "act-005", enrollment_id: "enr-001", lesson_id: "les-101-2", activity_type: "lesson_completed", activity_date: "2026-09-18 16:00:00", completed: true, created_at: "2026-09-18 16:00:00" },
      { activity_id: "act-006", enrollment_id: "enr-001", lesson_id: "les-101-3", activity_type: "lesson_completed", activity_date: "2026-09-22 17:00:00", completed: true, created_at: "2026-09-22 17:00:00" },
      { activity_id: "act-007", enrollment_id: "enr-001", lesson_id: "les-101-4", activity_type: "lesson_completed", activity_date: "2026-09-23 18:00:00", completed: true, created_at: "2026-09-23 18:00:00" },
      { activity_id: "act-008", enrollment_id: "enr-002", lesson_id: "les-101-1", activity_type: "lesson_opened", activity_date: "2026-10-14 09:00:00", completed: false, created_at: "2026-10-14 09:00:00" },
      { activity_id: "act-009", enrollment_id: "enr-002", lesson_id: "les-101-1", activity_type: "lesson_completed", activity_date: "2026-10-14 10:30:00", completed: true, created_at: "2026-10-14 10:30:00" },
      { activity_id: "act-010", enrollment_id: "enr-002", lesson_id: "les-101-2", activity_type: "lesson_started", activity_date: "2026-10-15 14:20:00", completed: false, created_at: "2026-10-15 14:20:00" },
      { activity_id: "act-011", enrollment_id: "enr-004", lesson_id: "les-101-1", activity_type: "lesson_completed", activity_date: "2026-09-10 12:00:00", completed: true, created_at: "2026-09-10 12:00:00" },
      { activity_id: "act-012", enrollment_id: "enr-004", lesson_id: "les-101-2", activity_type: "lesson_completed", activity_date: "2026-09-12 15:00:00", completed: true, created_at: "2026-09-12 15:00:00" },
      { activity_id: "act-013", enrollment_id: "enr-004", lesson_id: "les-101-3", activity_type: "lesson_completed", activity_date: "2026-09-14 16:30:00", completed: true, created_at: "2026-09-14 16:30:00" },
      { activity_id: "act-014", enrollment_id: "enr-005", lesson_id: "les-102-1", activity_type: "lesson_completed", activity_date: "2026-09-20 10:00:00", completed: true, created_at: "2026-09-20 10:00:00" },
      { activity_id: "act-015", enrollment_id: "enr-005", lesson_id: "les-102-2", activity_type: "lesson_completed", activity_date: "2026-09-25 11:00:00", completed: true, created_at: "2026-09-25 11:00:00" },
      { activity_id: "act-016", enrollment_id: "enr-005", lesson_id: "les-102-3", activity_type: "lesson_completed", activity_date: "2026-09-28 14:00:00", completed: true, created_at: "2026-09-28 14:00:00" },
      { activity_id: "act-017", enrollment_id: "enr-006", lesson_id: "les-102-1", activity_type: "lesson_started", activity_date: "2026-09-18 09:15:00", completed: false, created_at: "2026-09-18 09:15:00" },
      { activity_id: "act-018", enrollment_id: "enr-006", lesson_id: "les-102-1", activity_type: "lesson_completed", activity_date: "2026-09-18 10:45:00", completed: true, created_at: "2026-09-18 10:45:00" },
      { activity_id: "act-019", enrollment_id: "enr-008", lesson_id: "les-103-1", activity_type: "lesson_opened", activity_date: "2026-10-15 11:00:00", completed: false, created_at: "2026-10-15 11:00:00" },
      { activity_id: "act-020", enrollment_id: "enr-008", lesson_id: "les-103-1", activity_type: "video_watched", activity_date: "2026-10-15 11:30:00", completed: false, created_at: "2026-10-15 11:30:00" },
      { activity_id: "act-021", enrollment_id: "enr-008", lesson_id: "les-103-1", activity_type: "lesson_completed", activity_date: "2026-10-15 12:00:00", completed: true, created_at: "2026-10-15 12:00:00" },
      { activity_id: "act-022", enrollment_id: "enr-009", lesson_id: "les-103-1", activity_type: "lesson_completed", activity_date: "2026-09-28 15:00:00", completed: true, created_at: "2026-09-28 15:00:00" },
      { activity_id: "act-023", enrollment_id: "enr-009", lesson_id: "les-103-2", activity_type: "lesson_completed", activity_date: "2026-10-02 16:30:00", completed: true, created_at: "2026-10-02 16:30:00" },
      { activity_id: "act-024", enrollment_id: "enr-010", lesson_id: "les-104-1", activity_type: "resource_accessed", activity_date: "2026-10-16 14:00:00", completed: false, created_at: "2026-10-16 14:00:00" }
    ];
    const insertActivity = this.sqliteDb.prepare(`
      INSERT INTO activities (activity_id, enrollment_id, lesson_id, activity_type, activity_date, completed, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    initialActivities.forEach((a) => {
      this.activities.set(a.activity_id, a);
      insertActivity.run(a.activity_id, a.enrollment_id, a.lesson_id || null, a.activity_type, a.activity_date, a.completed ? 1 : 0, a.created_at);
    });
    const insertModule = this.sqliteDb.prepare(`
      INSERT INTO course_modules (module_id, course_id, module_name, description, sequence_no, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    initialCourseModules.forEach((m) => {
      this.modules.set(m.module_id, m);
      insertModule.run(m.module_id, m.course_id, m.module_name, m.description || null, m.sequence_no, m.created_at, m.updated_at);
    });
    const insertVideo = this.sqliteDb.prepare(`
      INSERT INTO module_videos (video_id, module_id, course_id, title, youtube_video_id, youtube_url, embed_url, thumbnail_url, duration, duration_seconds, channel_name, description, sequence_no, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    initialModuleVideos.forEach((v) => {
      this.videos.set(v.video_id, v);
      insertVideo.run(
        v.video_id,
        v.module_id,
        v.course_id,
        v.title,
        v.youtube_video_id,
        v.youtube_url,
        v.embed_url,
        v.thumbnail_url || null,
        v.duration,
        v.duration_seconds,
        v.channel_name || null,
        v.description || null,
        v.sequence_no,
        v.created_at,
        v.updated_at
      );
    });
  }
  getCourses() {
    return Array.from(this.courses.values());
  }
  getModulesByCourse(courseId) {
    const mods = Array.from(this.modules.values()).filter((m) => m.course_id === courseId).sort((a, b) => a.sequence_no - b.sequence_no);
    return mods.map((m) => {
      const vids = this.getVideosByModule(m.module_id);
      return {
        ...m,
        title: m.title || m.module_name,
        video_count: vids.length,
        videos: vids
      };
    });
  }
  getVideosByModule(moduleId) {
    return Array.from(this.videos.values()).filter((v) => v.module_id === moduleId).sort((a, b) => a.sequence_no - b.sequence_no);
  }
  getVideosByCourse(courseId) {
    return Array.from(this.videos.values()).filter((v) => v.course_id === courseId).sort((a, b) => a.sequence_no - b.sequence_no);
  }
  getVideo(videoId) {
    return this.videos.get(videoId);
  }
  getCompletedVideosForEnrollment(enrollmentId) {
    return Array.from(this.activities.values()).filter((a) => a.enrollment_id === enrollmentId && a.activity_type === "video_watched" && a.completed).map((a) => a.lesson_id).filter((id) => Boolean(id));
  }
  insertActivity(actData) {
    const actId = `act-${Date.now().toString().slice(-6)}-${Math.random().toString(36).substring(2, 5)}`;
    const now = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
    const activity = {
      activity_id: actId,
      enrollment_id: actData.enrollment_id,
      lesson_id: actData.lesson_id,
      activity_type: actData.activity_type,
      activity_date: now,
      completed: actData.completed ?? false,
      created_at: now
    };
    this.upsertActivity(activity);
    return activity;
  }
  upsertModule(mod) {
    this.modules.set(mod.module_id, mod);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO course_modules (module_id, course_id, module_name, description, sequence_no, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(module_id) DO UPDATE SET
        module_name = excluded.module_name,
        description = excluded.description,
        sequence_no = excluded.sequence_no,
        updated_at = excluded.updated_at
    `);
    stmt.run(mod.module_id, mod.course_id, mod.module_name || mod.title || "", mod.description || null, mod.sequence_no, mod.created_at, mod.updated_at);
  }
  upsertVideo(vid) {
    this.videos.set(vid.video_id, vid);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO module_videos (video_id, module_id, course_id, title, youtube_video_id, youtube_url, embed_url, thumbnail_url, duration, duration_seconds, channel_name, description, sequence_no, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(video_id) DO UPDATE SET
        title = excluded.title,
        youtube_video_id = excluded.youtube_video_id,
        youtube_url = excluded.youtube_url,
        embed_url = excluded.embed_url,
        thumbnail_url = excluded.thumbnail_url,
        duration = excluded.duration,
        duration_seconds = excluded.duration_seconds,
        channel_name = excluded.channel_name,
        description = excluded.description,
        sequence_no = excluded.sequence_no,
        updated_at = excluded.updated_at
    `);
    stmt.run(
      vid.video_id,
      vid.module_id,
      vid.course_id,
      vid.title,
      vid.youtube_video_id,
      vid.youtube_url,
      vid.embed_url,
      vid.thumbnail_url || null,
      vid.duration,
      vid.duration_seconds,
      vid.channel_name || null,
      vid.description || null,
      vid.sequence_no,
      vid.created_at,
      vid.updated_at
    );
  }
  updateVideo(videoId, updates) {
    const existing = this.videos.get(videoId);
    if (!existing) return null;
    let embed_url = updates.embed_url || existing.embed_url;
    let youtube_video_id = updates.youtube_video_id || existing.youtube_video_id;
    let thumbnail_url = updates.thumbnail_url || existing.thumbnail_url;
    if (updates.youtube_url && updates.youtube_url !== existing.youtube_url) {
      const match = updates.youtube_url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
      if (match && match[1]) {
        youtube_video_id = match[1];
        embed_url = `https://www.youtube-nocookie.com/embed/${match[1]}`;
        thumbnail_url = `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg`;
      }
    }
    const updated = {
      ...existing,
      ...updates,
      youtube_video_id,
      embed_url,
      thumbnail_url,
      updated_at: (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19)
    };
    this.upsertVideo(updated);
    return updated;
  }
  // Synchronizers for updates & inserts
  upsertCourse(course) {
    this.courses.set(course.course_id, course);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO courses (course_id, course_name, category, description, created_at, updated_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(course_id) DO UPDATE SET
        course_name = excluded.course_name,
        category = excluded.category,
        description = excluded.description,
        updated_at = excluded.updated_at,
        is_active = excluded.is_active
    `);
    stmt.run(course.course_id, course.course_name, course.category, course.description || null, course.created_at, course.updated_at, course.is_active ? 1 : 0);
  }
  upsertLearner(learner) {
    this.learners.set(learner.learner_id, learner);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO learners (learner_id, roll_no, display_name, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(learner_id) DO UPDATE SET
        roll_no = excluded.roll_no,
        display_name = excluded.display_name,
        updated_at = excluded.updated_at
    `);
    stmt.run(learner.learner_id, learner.roll_no || null, learner.display_name, learner.created_at, learner.updated_at);
  }
  upsertEnrollment(enr) {
    this.enrollments.set(enr.enrollment_id, enr);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO enrollments (enrollment_id, learner_id, course_id, status, enrolled_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(enrollment_id) DO UPDATE SET
        status = excluded.status,
        updated_at = excluded.updated_at
    `);
    stmt.run(enr.enrollment_id, enr.learner_id, enr.course_id, enr.status, enr.enrolled_at, enr.updated_at);
  }
  upsertLesson(lesson) {
    this.lessons.set(lesson.lesson_id, lesson);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO lessons (lesson_id, course_id, lesson_name, sequence_no, is_required, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(lesson_id) DO UPDATE SET
        lesson_name = excluded.lesson_name,
        sequence_no = excluded.sequence_no,
        is_required = excluded.is_required
    `);
    stmt.run(lesson.lesson_id, lesson.course_id, lesson.lesson_name, lesson.sequence_no, lesson.is_required ? 1 : 0, lesson.created_at);
  }
  upsertActivity(act) {
    this.activities.set(act.activity_id, act);
    const stmt = this.sqliteDb.prepare(`
      INSERT INTO activities (activity_id, enrollment_id, lesson_id, activity_type, activity_date, completed, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(activity_id) DO UPDATE SET
        lesson_id = excluded.lesson_id,
        activity_type = excluded.activity_type,
        activity_date = excluded.activity_date,
        completed = excluded.completed
    `);
    stmt.run(act.activity_id, act.enrollment_id, act.lesson_id || null, act.activity_type, act.activity_date, act.completed ? 1 : 0, act.created_at);
  }
  // -------------------------------------------------------------------
  // PARAMETERIZED DATABASE SEARCH QUERIES
  // -------------------------------------------------------------------
  /**
   * Searches courses by course_name and category using parameterized SQL queries.
   */
  searchCourses(query, category, isActive) {
    const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
    let sql = "SELECT * FROM courses WHERE 1=1";
    const params = [];
    if (cleanQuery) {
      const escaped = cleanQuery.replace(/[%_\\]/g, "\\$&");
      sql += ` AND (LOWER(course_name) LIKE ? ESCAPE '\\' OR LOWER(category) LIKE ? ESCAPE '\\' OR LOWER(course_id) LIKE ? ESCAPE '\\')`;
      params.push(`%${escaped}%`, `%${escaped}%`, `%${escaped}%`);
    }
    if (category && category !== "All") {
      sql += " AND category = ?";
      params.push(category);
    }
    if (isActive !== void 0) {
      sql += " AND is_active = ?";
      params.push(isActive ? 1 : 0);
    }
    sql += " ORDER BY created_at DESC";
    try {
      const stmt = this.sqliteDb.prepare(sql);
      const rows = stmt.all(...params);
      return rows.map((r) => ({
        course_id: r.course_id,
        course_name: r.course_name,
        category: r.category,
        description: r.description || void 0,
        created_at: r.created_at,
        updated_at: r.updated_at,
        is_active: Boolean(r.is_active)
      }));
    } catch {
      let list = Array.from(this.courses.values());
      if (cleanQuery) list = searchCourses(list, cleanQuery);
      if (category && category !== "All") list = list.filter((c) => c.category === category);
      if (isActive !== void 0) list = list.filter((c) => c.is_active === isActive);
      return list;
    }
  }
  /**
   * Searches learners by display_name and roll_no using parameterized SQL queries.
   */
  searchLearners(query) {
    const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
    let sql = "SELECT * FROM learners WHERE 1=1";
    const params = [];
    if (cleanQuery) {
      const escaped = cleanQuery.replace(/[%_\\]/g, "\\$&");
      sql += ` AND (LOWER(display_name) LIKE ? ESCAPE '\\' OR LOWER(COALESCE(roll_no, '')) LIKE ? ESCAPE '\\' OR LOWER(learner_id) LIKE ? ESCAPE '\\')`;
      params.push(`%${escaped}%`, `%${escaped}%`, `%${escaped}%`);
    }
    sql += " ORDER BY created_at ASC";
    try {
      const stmt = this.sqliteDb.prepare(sql);
      const rows = stmt.all(...params);
      return rows.map((r) => ({
        learner_id: r.learner_id,
        display_name: r.display_name,
        roll_no: r.roll_no || void 0,
        created_at: r.created_at,
        updated_at: r.updated_at
      }));
    } catch {
      const list = Array.from(this.learners.values());
      return cleanQuery ? searchLearners(list, cleanQuery) : list;
    }
  }
  /**
   * Searches enrolments by enrolment ID, learner identifier, and course name using parameterized SQL queries.
   */
  searchEnrollments(query, courseId, learnerId, status) {
    const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
    let sql = `
      SELECT 
        e.*,
        c.course_name,
        c.category as course_category,
        l.display_name as learner_name,
        l.roll_no
      FROM enrollments e
      JOIN courses c ON e.course_id = c.course_id
      JOIN learners l ON e.learner_id = l.learner_id
      WHERE 1=1
    `;
    const params = [];
    if (cleanQuery) {
      const escaped = cleanQuery.replace(/[%_\\]/g, "\\$&");
      sql += ` AND (
        LOWER(e.enrollment_id) LIKE ? ESCAPE '\\' 
        OR LOWER(l.display_name) LIKE ? ESCAPE '\\' 
        OR LOWER(COALESCE(l.roll_no, '')) LIKE ? ESCAPE '\\' 
        OR LOWER(l.learner_id) LIKE ? ESCAPE '\\' 
        OR LOWER(c.course_name) LIKE ? ESCAPE '\\'
        OR LOWER(c.course_id) LIKE ? ESCAPE '\\'
      )`;
      params.push(`%${escaped}%`, `%${escaped}%`, `%${escaped}%`, `%${escaped}%`, `%${escaped}%`, `%${escaped}%`);
    }
    if (courseId && courseId !== "All") {
      sql += " AND e.course_id = ?";
      params.push(courseId);
    }
    if (learnerId && learnerId !== "All") {
      sql += " AND e.learner_id = ?";
      params.push(learnerId);
    }
    if (status && status !== "All") {
      sql += " AND e.status = ?";
      params.push(status);
    }
    sql += " ORDER BY e.enrolled_at DESC";
    try {
      const stmt = this.sqliteDb.prepare(sql);
      return stmt.all(...params);
    } catch {
      let list = Array.from(this.enrollments.values());
      if (cleanQuery) list = searchEnrollments(list, this.courses, this.learners, cleanQuery);
      if (courseId && courseId !== "All") list = list.filter((e) => e.course_id === courseId);
      if (learnerId && learnerId !== "All") list = list.filter((e) => e.learner_id === learnerId);
      if (status && status !== "All") list = list.filter((e) => e.status === status);
      return list.map((e) => {
        const c = this.courses.get(e.course_id);
        const l = this.learners.get(e.learner_id);
        return {
          ...e,
          course_name: c ? c.course_name : e.course_id,
          course_category: c?.category,
          learner_name: l ? l.display_name : e.learner_id,
          roll_no: l?.roll_no
        };
      });
    }
  }
  /**
   * Searches activities by activity_type and enrolment ID using parameterized SQL queries.
   */
  searchActivities(query, courseId, enrollmentId, activityType) {
    const cleanQuery = sanitizeSearchQuery(query).toLowerCase();
    let sql = `
      SELECT 
        a.*,
        e.course_id,
        e.learner_id,
        c.course_name,
        l.display_name as learner_name,
        les.lesson_name
      FROM activities a
      JOIN enrollments e ON a.enrollment_id = e.enrollment_id
      JOIN courses c ON e.course_id = c.course_id
      JOIN learners l ON e.learner_id = l.learner_id
      LEFT JOIN lessons les ON a.lesson_id = les.lesson_id
      WHERE 1=1
    `;
    const params = [];
    if (cleanQuery) {
      const escaped = cleanQuery.replace(/[%_\\]/g, "\\$&");
      sql += ` AND (
        LOWER(a.activity_type) LIKE ? ESCAPE '\\'
        OR LOWER(REPLACE(a.activity_type, '_', ' ')) LIKE ? ESCAPE '\\'
        OR LOWER(a.enrollment_id) LIKE ? ESCAPE '\\'
        OR LOWER(a.activity_id) LIKE ? ESCAPE '\\'
      )`;
      params.push(`%${escaped}%`, `%${escaped}%`, `%${escaped}%`, `%${escaped}%`);
    }
    if (enrollmentId && enrollmentId !== "All") {
      sql += " AND a.enrollment_id = ?";
      params.push(enrollmentId);
    }
    if (activityType && activityType !== "All") {
      sql += " AND a.activity_type = ?";
      params.push(activityType);
    }
    if (courseId && courseId !== "All") {
      sql += " AND e.course_id = ?";
      params.push(courseId);
    }
    sql += " ORDER BY a.activity_date DESC";
    try {
      const stmt = this.sqliteDb.prepare(sql);
      const rows = stmt.all(...params);
      return rows.map((r) => ({
        ...r,
        completed: Boolean(r.completed)
      }));
    } catch {
      let list = Array.from(this.activities.values());
      if (cleanQuery) list = searchActivities(list, cleanQuery);
      if (enrollmentId && enrollmentId !== "All") list = list.filter((a) => a.enrollment_id === enrollmentId);
      if (activityType && activityType !== "All") list = list.filter((a) => a.activity_type === activityType);
      if (courseId && courseId !== "All") {
        list = list.filter((a) => {
          const enr = this.enrollments.get(a.enrollment_id);
          return enr && enr.course_id === courseId;
        });
      }
      return list.map((a) => {
        const enr = this.enrollments.get(a.enrollment_id);
        const c = enr ? this.courses.get(enr.course_id) : void 0;
        const l = enr ? this.learners.get(enr.learner_id) : void 0;
        const les = a.lesson_id ? this.lessons.get(a.lesson_id) : void 0;
        return {
          ...a,
          course_id: enr?.course_id,
          course_name: c?.course_name,
          learner_id: enr?.learner_id,
          learner_name: l?.display_name,
          lesson_name: les?.lesson_name
        };
      });
    }
  }
  /**
   * Executes Global Search across courses, learners, enrolments, and activities.
   */
  globalSearch(query) {
    const cleanQuery = sanitizeSearchQuery(query);
    if (!cleanQuery) {
      return {
        query: "",
        total_matches: 0,
        results: {
          courses: [],
          learners: [],
          enrollments: [],
          activities: []
        }
      };
    }
    const matchedCourses = this.searchCourses(cleanQuery);
    const matchedLearners = this.searchLearners(cleanQuery);
    const matchedEnrollments = this.searchEnrollments(cleanQuery);
    const matchedActivities = this.searchActivities(cleanQuery);
    const formattedCourses = matchedCourses.map((c) => ({
      id: c.course_id,
      type: "course",
      title: c.course_name,
      subtitle: `Category: ${c.category}`,
      details: `${c.is_active ? "Active" : "Inactive"} \u2022 Created ${c.created_at.slice(0, 10)}`,
      metadata: {
        category: c.category,
        is_active: c.is_active
      }
    }));
    const formattedLearners = matchedLearners.map((l) => ({
      id: l.learner_id,
      type: "learner",
      title: l.display_name,
      subtitle: l.roll_no ? `Roll No: ${l.roll_no}` : "No roll number",
      details: `Learner ID: ${l.learner_id} \u2022 Registered ${l.created_at.slice(0, 10)}`,
      metadata: {
        roll_no: l.roll_no
      }
    }));
    const formattedEnrollments = matchedEnrollments.map((e) => ({
      id: e.enrollment_id,
      type: "enrollment",
      title: `${e.learner_name || e.learner_id} in ${e.course_name || e.course_id}`,
      subtitle: `Enrolment ID: ${e.enrollment_id} \u2022 Status: ${String(e.status).toUpperCase()}`,
      details: `Enrolled on ${String(e.enrolled_at).slice(0, 10)}`,
      metadata: {
        status: e.status,
        course_id: e.course_id,
        learner_id: e.learner_id
      }
    }));
    const formattedActivities = matchedActivities.map((a) => {
      const friendlyType = String(a.activity_type).replace(/_/g, " ").replace(/\b\w/g, (ch) => ch.toUpperCase());
      return {
        id: a.activity_id,
        type: "activity",
        title: `${friendlyType} (${a.completed ? "Completed" : "Logged"})`,
        subtitle: `Enrolment: ${a.enrollment_id} \u2022 ${a.learner_name || "Learner"}`,
        details: `${a.course_name || "Course"} \u2022 ${a.lesson_name || "General resource"} \u2022 ${a.activity_date}`,
        metadata: {
          activity_type: a.activity_type,
          completed: a.completed,
          enrollment_id: a.enrollment_id
        }
      };
    });
    const totalMatches = formattedCourses.length + formattedLearners.length + formattedEnrollments.length + formattedActivities.length;
    return {
      query: cleanQuery,
      total_matches: totalMatches,
      results: {
        courses: formattedCourses,
        learners: formattedLearners,
        enrollments: formattedEnrollments,
        activities: formattedActivities
      }
    };
  }
  getDatabaseHealth() {
    try {
      const stmt = this.sqliteDb.prepare("SELECT COUNT(*) as count FROM courses");
      const result = stmt.get();
      const mysqlHost = process.env.DB_HOST || process.env.MYSQL_HOST || "";
      const mysqlPort = process.env.DB_PORT || process.env.MYSQL_PORT || "3306";
      const mysqlUser = process.env.DB_USER || process.env.MYSQL_USER || "";
      const mysqlDb = process.env.DB_NAME || process.env.MYSQL_DATABASE || "elearning_analytics";
      const isMysqlConfigured = Boolean(mysqlHost && mysqlUser);
      return {
        status: "healthy",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        relational_store: {
          engine: "SQLite3 (Node.js DatabaseSync)",
          status: "connected",
          tables: {
            courses: this.courses.size,
            learners: this.learners.size,
            enrollments: this.enrollments.size,
            lessons: this.lessons.size,
            activities: this.activities.size
          },
          verified_by_query: result ? result.count === this.courses.size : true
        },
        mysql_connection: {
          configured: isMysqlConfigured,
          connected: false,
          // Truthful reporting: no live remote MySQL server attached
          host: mysqlHost ? `${mysqlHost}:${mysqlPort}` : "Not set in environment",
          database: mysqlDb,
          message: isMysqlConfigured ? `MySQL credentials configured for host "${mysqlHost}", but external daemon is not active. Relational operations safely executing on embedded relational engine.` : "MySQL host not configured (DB_HOST/MYSQL_HOST). Running in standalone relational mode matching MySQL 8 schema."
        },
        schema_alignment: "Strictly aligned with database/schema.sql (MySQL 8 DDL)"
      };
    } catch (err) {
      return {
        status: "degraded",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message
      };
    }
  }
};
var dbStore = new RelationalStore();

// backend/src/services/authService.ts
import bcrypt from "bcryptjs";
import crypto from "node:crypto";
var AuthService = class {
  // 24 hours
  constructor() {
    this.activeSessions = /* @__PURE__ */ new Map();
    this.SESSION_DURATION_MS = 24 * 60 * 60 * 1e3;
    this.secretKey = process.env.AUTH_SECRET || process.env.ADMIN_SECRET || "edupulse-auth-secret-key-2026";
    const defaultUsername = process.env.ADMIN_USERNAME?.trim() || "admin";
    const defaultPassword = process.env.ADMIN_PASSWORD?.trim() || "Admin@EduPulse2026!";
    const saltRounds = 10;
    const initialHash = bcrypt.hashSync(defaultPassword, saltRounds);
    this.adminUser = {
      username: defaultUsername,
      passwordHash: initialHash,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  /**
   * Verify provided administrator credentials using bcrypt constant-time comparison
   */
  verifyCredentials(username, password) {
    if (!username || !password) return false;
    if (username.trim().toLowerCase() !== this.adminUser.username.toLowerCase()) {
      return false;
    }
    return bcrypt.compareSync(password, this.adminUser.passwordHash);
  }
  /**
   * Create a new secure session token
   */
  createSession(username) {
    const rawId = crypto.randomBytes(32).toString("hex");
    const signature = crypto.createHmac("sha256", this.secretKey).update(`${username}:${rawId}`).digest("hex");
    const token = `${rawId}.${signature}`;
    const now = Date.now();
    const session = {
      token,
      username,
      role: "administrator",
      createdAt: now,
      expiresAt: now + this.SESSION_DURATION_MS
    };
    this.activeSessions.set(token, session);
    return session;
  }
  /**
   * Validate session token from Authorization: Bearer <token>
   */
  validateToken(token) {
    if (!token || typeof token !== "string") return null;
    const cleanToken = token.startsWith("Bearer ") ? token.slice(7).trim() : token.trim();
    if (!cleanToken) return null;
    const session = this.activeSessions.get(cleanToken);
    if (!session) return null;
    if (Date.now() > session.expiresAt) {
      this.activeSessions.delete(cleanToken);
      return null;
    }
    return session;
  }
  /**
   * Destroy an active session (logout)
   */
  destroySession(token) {
    if (!token) return false;
    const cleanToken = token.startsWith("Bearer ") ? token.slice(7).trim() : token.trim();
    return this.activeSessions.delete(cleanToken);
  }
  /**
   * Update administrator password securely
   */
  updatePassword(oldPassword, newPassword) {
    if (!this.verifyCredentials(this.adminUser.username, oldPassword)) {
      return { success: false, message: "Current administrator password is incorrect." };
    }
    if (!newPassword || newPassword.length < 8) {
      return { success: false, message: "New password must be at least 8 characters long." };
    }
    this.adminUser.passwordHash = bcrypt.hashSync(newPassword, 10);
    this.adminUser.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.activeSessions.clear();
    return { success: true, message: "Administrator password updated successfully." };
  }
  /**
   * Safe status object for frontend setup assistance without exposing secrets
   */
  getStatus() {
    return {
      username: this.adminUser.username,
      activeSessionsCount: this.activeSessions.size,
      hasCustomPasswordEnv: Boolean(process.env.ADMIN_PASSWORD),
      defaultDemoHint: !process.env.ADMIN_PASSWORD ? "Admin@EduPulse2026!" : void 0
    };
  }
};
var authService = new AuthService();

// backend/src/services/analyticsLogic.ts
function calculateCompletionRates(courses, enrollments, eligibilityPolicy = "enrolled_and_completed") {
  return courses.map((course) => {
    const cEnrs = enrollments.filter((e) => e.course_id === course.course_id);
    const eligibleEnrs = cEnrs.filter((e) => e.status === "enrolled" || e.status === "completed");
    const completedEnrs = eligibleEnrs.filter((e) => e.status === "completed");
    const totalEligible = eligibleEnrs.length;
    const completedCount = completedEnrs.length;
    const withdrawnCount = cEnrs.filter((e) => e.status === "withdrawn").length;
    const cancelledCount = cEnrs.filter((e) => e.status === "cancelled").length;
    const completionRate = totalEligible > 0 ? Number((completedCount / totalEligible * 100).toFixed(1)) : 0;
    return {
      course_id: course.course_id,
      course_name: course.course_name,
      category: course.category,
      is_active: course.is_active,
      total_enrolments: cEnrs.length,
      eligible_enrolments: totalEligible,
      completed_enrolments: completedCount,
      withdrawn_enrolments: withdrawnCount,
      cancelled_enrolments: cancelledCount,
      completion_rate_percent: completionRate,
      formula: "completed_enrolments / eligible_enrolments * 100",
      denominator_definition: 'Count of distinct enrolments with status in ("enrolled", "completed")'
    };
  });
}
function calculateEnrolmentProgress(enrollment, lessons, activities, courseName, learnerName) {
  const courseLessons = lessons.filter((l) => l.course_id === enrollment.course_id);
  const requiredLessons = courseLessons.filter((l) => l.is_required);
  const optionalLessons = courseLessons.filter((l) => !l.is_required);
  const requiredLessonIds = new Set(requiredLessons.map((l) => l.lesson_id));
  const optionalLessonIds = new Set(optionalLessons.map((l) => l.lesson_id));
  const enrActivities = activities.filter((a) => a.enrollment_id === enrollment.enrollment_id);
  const completedLessonIds = /* @__PURE__ */ new Set();
  for (const act of enrActivities) {
    if (act.completed && act.lesson_id) {
      completedLessonIds.add(act.lesson_id);
    }
  }
  let distinctRequiredCompleted = 0;
  for (const id of completedLessonIds) {
    if (requiredLessonIds.has(id)) {
      distinctRequiredCompleted++;
    }
  }
  let distinctOptionalCompleted = 0;
  for (const id of completedLessonIds) {
    if (optionalLessonIds.has(id)) {
      distinctOptionalCompleted++;
    }
  }
  const totalRequired = requiredLessons.length;
  let progressPercentage = 0;
  if (totalRequired > 0) {
    progressPercentage = Number(Math.min(100, distinctRequiredCompleted / totalRequired * 100).toFixed(1));
  } else {
    progressPercentage = 0;
  }
  const isFullyCompleted = totalRequired > 0 && distinctRequiredCompleted === totalRequired;
  let progressBand = "0-24%";
  if (progressPercentage === 100) progressBand = "100%";
  else if (progressPercentage >= 75) progressBand = "75-99%";
  else if (progressPercentage >= 50) progressBand = "50-74%";
  else if (progressPercentage >= 25) progressBand = "25-49%";
  return {
    enrollment_id: enrollment.enrollment_id,
    learner_id: enrollment.learner_id,
    learner_name: learnerName,
    course_id: enrollment.course_id,
    course_name: courseName,
    status: enrollment.status,
    total_required_lessons: totalRequired,
    total_optional_lessons: optionalLessons.length,
    distinct_required_completed: distinctRequiredCompleted,
    distinct_optional_completed: distinctOptionalCompleted,
    progress_percentage: progressPercentage,
    progress_band: progressBand,
    is_fully_completed: isFullyCompleted
  };
}
function getWeeklyActivitySummary(activities, enrollmentsMap = /* @__PURE__ */ new Map()) {
  const weeksMap = /* @__PURE__ */ new Map();
  for (const act of activities) {
    const d = new Date(act.activity_date);
    if (isNaN(d.getTime())) continue;
    const tempDate = new Date(d.valueOf());
    const dayNr = (d.getUTCDay() + 6) % 7;
    tempDate.setUTCDate(tempDate.getUTCDate() - dayNr + 3);
    const firstThursday = tempDate.valueOf();
    tempDate.setUTCMonth(0, 1);
    if (tempDate.getUTCDay() !== 4) {
      tempDate.setUTCMonth(0, 1 + (4 - tempDate.getUTCDay() + 7) % 7);
    }
    const weekNumber = 1 + Math.ceil((firstThursday - tempDate.valueOf()) / 6048e5);
    const year = tempDate.getUTCFullYear();
    const weekKey = `${year}-W${String(weekNumber).padStart(2, "0")}`;
    if (!weeksMap.has(weekKey)) {
      weeksMap.set(weekKey, {
        week_label: `W${weekNumber} (${year})`,
        total_events: 0,
        completed_events: 0,
        active_enrolments: /* @__PURE__ */ new Set(),
        active_learners: /* @__PURE__ */ new Set(),
        breakdown: {}
      });
    }
    const entry = weeksMap.get(weekKey);
    entry.total_events++;
    if (act.completed) entry.completed_events++;
    if (act.enrollment_id) {
      entry.active_enrolments.add(act.enrollment_id);
      const enr = enrollmentsMap.get(act.enrollment_id);
      if (enr) entry.active_learners.add(enr.learner_id);
    }
    const typeKey = act.activity_type || "other";
    entry.breakdown[typeKey] = (entry.breakdown[typeKey] || 0) + 1;
  }
  const sortedKeys = Array.from(weeksMap.keys()).sort();
  return sortedKeys.map((key) => {
    const item = weeksMap.get(key);
    return {
      week_key: key,
      week_label: item.week_label,
      total_events: item.total_events,
      completed_events: item.completed_events,
      distinct_active_enrollments: item.active_enrolments.size,
      distinct_active_learners: item.active_learners.size,
      breakdown: item.breakdown
    };
  });
}
function getInactivityAnalysis(enrollments, activities, coursesMap, learnersMap, inactivityThresholdDays = 14, referenceTimestamp = /* @__PURE__ */ new Date()) {
  const enrActivities = /* @__PURE__ */ new Map();
  for (const act of activities) {
    if (!enrActivities.has(act.enrollment_id)) {
      enrActivities.set(act.enrollment_id, []);
    }
    enrActivities.get(act.enrollment_id).push(act);
  }
  const records = [];
  let flaggedCount = 0;
  let activeCount = 0;
  let noHistoryCount = 0;
  let excludedCount = 0;
  for (const enr of enrollments) {
    const course = coursesMap.get(enr.course_id);
    const learner = learnersMap.get(enr.learner_id);
    const courseName = course ? course.course_name : enr.course_id;
    const learnerName = learner ? learner.display_name : enr.learner_id;
    const rollNo = learner?.roll_no;
    const acts = enrActivities.get(enr.enrollment_id) || [];
    let inactivityStatus;
    let isFlagged = false;
    let flagReason = "";
    let daysSinceLast = null;
    let lastRecordedActivity = null;
    if (enr.status === "withdrawn" || enr.status === "cancelled") {
      inactivityStatus = "excluded_by_status";
      flagReason = `Enrolment is ${enr.status}; excluded from inactivity monitoring.`;
      excludedCount++;
    } else if (enr.status === "completed") {
      inactivityStatus = "completed_enrolment";
      flagReason = "Enrolment has already been completed.";
    } else if (acts.length === 0) {
      inactivityStatus = "no_activity_history";
      flagReason = "No learning activity has ever been recorded for this enrolment.";
      isFlagged = true;
      flaggedCount++;
      noHistoryCount++;
    } else {
      let latestTime = 0;
      for (const a of acts) {
        const t = new Date(a.activity_date).getTime();
        if (t > latestTime) {
          latestTime = t;
        }
      }
      if (latestTime > 0) {
        const diffMs = referenceTimestamp.getTime() - latestTime;
        daysSinceLast = Math.max(0, Math.floor(diffMs / (1e3 * 60 * 60 * 24)));
        lastRecordedActivity = new Date(latestTime).toISOString().replace("T", " ").slice(0, 19);
        if (daysSinceLast > inactivityThresholdDays) {
          inactivityStatus = "no_activity_within_window";
          flagReason = `No activity recorded in the past ${daysSinceLast} days (threshold: ${inactivityThresholdDays} days).`;
          isFlagged = true;
          flaggedCount++;
        } else {
          inactivityStatus = "active_within_window";
          flagReason = `Active ${daysSinceLast} days ago (within ${inactivityThresholdDays}-day window).`;
          activeCount++;
        }
      } else {
        inactivityStatus = "no_activity_history";
        flagReason = "Activity timestamps could not be validated.";
        isFlagged = true;
        flaggedCount++;
        noHistoryCount++;
      }
    }
    records.push({
      enrollment_id: enr.enrollment_id,
      learner_id: enr.learner_id,
      learner_name: learnerName,
      roll_no: rollNo,
      course_id: enr.course_id,
      course_name: courseName,
      enrollment_status: enr.status,
      inactivity_status: inactivityStatus,
      is_flagged: isFlagged,
      last_recorded_activity: lastRecordedActivity,
      days_since_last_activity: daysSinceLast,
      configured_threshold_days: inactivityThresholdDays,
      flag_reason: flagReason
    });
  }
  return {
    reference_timestamp: referenceTimestamp.toISOString(),
    inactivity_threshold_days: inactivityThresholdDays,
    total_monitored: enrollments.length,
    flagged_count: flaggedCount,
    active_in_window_count: activeCount,
    no_history_count: noHistoryCount,
    excluded_count: excludedCount,
    records
  };
}
function escapeCsvField(val) {
  if (val === null || val === void 0) return '""';
  let str = String(val).trim();
  const dangerousPrefixes = ["=", "+", "-", "@", "	", "\r"];
  if (dangerousPrefixes.some((prefix) => str.startsWith(prefix))) {
    str = "'" + str;
  }
  const escaped = str.replace(/"/g, '""');
  return `"${escaped}"`;
}

// backend/src/routes/api.ts
var apiRouter = Router();
apiRouter.use((req, res, next) => {
  const authHeader = req.headers["authorization"];
  if (authHeader) {
    const session = authService.validateToken(authHeader);
    if (session) {
      req.user = session;
      req.userRole = "administrator";
      return next();
    } else {
      req.invalidToken = true;
    }
  }
  const roleHeader = req.headers["x-user-role"] || "";
  if (roleHeader.toLowerCase() === "analyst") {
    req.userRole = "analyst";
  } else {
    req.userRole = "unauthenticated";
  }
  next();
});
function requireAdmin(req, res, next) {
  if (req.invalidToken) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Invalid or expired administrator token. Please log in again."
    });
  }
  const user = req.user;
  const role = req.userRole;
  if (role === "analyst") {
    return res.status(403).json({
      error: "Forbidden",
      message: 'Role "Administrator" is required to perform this action. Analysts have read-only access to analytics and exports.'
    });
  }
  if (!user || user.role !== "administrator") {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Authentication required. Please sign in as an Administrator with a valid password to perform this action."
    });
  }
  next();
}
apiRouter.post("/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({
      error: "Validation Error",
      message: "Username and password are required."
    });
  }
  const isValid = authService.verifyCredentials(String(username), String(password));
  if (!isValid) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Invalid administrator credentials. Please check your username and password."
    });
  }
  const session = authService.createSession(String(username));
  res.json({
    message: "Authentication successful",
    token: session.token,
    user: {
      username: session.username,
      role: session.role
    },
    expiresAt: session.expiresAt
  });
});
apiRouter.get("/auth/me", (req, res) => {
  const authHeader = req.headers["authorization"];
  const session = authService.validateToken(authHeader);
  if (session) {
    return res.json({
      authenticated: true,
      user: {
        username: session.username,
        role: session.role
      }
    });
  }
  res.json({
    authenticated: false,
    role: "analyst"
  });
});
apiRouter.post("/auth/logout", (req, res) => {
  const authHeader = req.headers["authorization"];
  if (authHeader) {
    authService.destroySession(authHeader);
  }
  res.json({ message: "Logged out successfully" });
});
apiRouter.get("/auth/status", (_req, res) => {
  res.json({ data: authService.getStatus() });
});
apiRouter.get("/search", (req, res) => {
  const query = sanitizeSearchQuery(req.query.q || req.query.search || "");
  const result = dbStore.globalSearch(query);
  res.json({ data: result });
});
apiRouter.get("/courses", (req, res) => {
  const searchQuery = req.query.search !== void 0 ? sanitizeSearchQuery(req.query.search) : void 0;
  const category = req.query.category && req.query.category !== "All" ? String(req.query.category) : void 0;
  const isActive = req.query.is_active !== void 0 && req.query.is_active !== "" && req.query.is_active !== "All" ? req.query.is_active === "true" || req.query.is_active === "1" : void 0;
  const courses = dbStore.searchCourses(searchQuery, category, isActive);
  const enriched = courses.map((c) => {
    const cLessons = Array.from(dbStore.lessons.values()).filter((l) => l.course_id === c.course_id);
    const requiredCount = cLessons.filter((l) => l.is_required).length;
    const optionalCount = cLessons.filter((l) => !l.is_required).length;
    const cEnrs = Array.from(dbStore.enrollments.values()).filter((e) => e.course_id === c.course_id);
    const cModules = dbStore.getModulesByCourse(c.course_id);
    const totalVideos = cModules.reduce((acc, m) => acc + (m.videos?.length || 0), 0);
    return {
      ...c,
      total_lessons: cLessons.length,
      required_lessons: requiredCount,
      optional_lessons: optionalCount,
      enrolment_count: cEnrs.length,
      total_modules: cModules.length,
      total_videos: totalVideos
    };
  });
  res.json({ data: enriched });
});
apiRouter.post("/courses", requireAdmin, (req, res) => {
  const { course_name, category, description, is_active } = req.body;
  if (!course_name || typeof course_name !== "string" || !course_name.trim()) {
    return res.status(400).json({ error: "Validation Error", message: "course_name is required" });
  }
  if (!category || typeof category !== "string" || !category.trim()) {
    return res.status(400).json({ error: "Validation Error", message: "category is required" });
  }
  const course_id = `crs-${Date.now().toString().slice(-6)}`;
  const now = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  const newCourse = {
    course_id,
    course_name: course_name.trim(),
    category: category.trim(),
    description: description ? String(description).trim() : void 0,
    created_at: now,
    updated_at: now,
    is_active: is_active !== false
  };
  dbStore.upsertCourse(newCourse);
  res.status(201).json({ message: "Course created successfully", data: newCourse });
});
apiRouter.get("/courses/:id", (req, res) => {
  const course = dbStore.courses.get(req.params.id);
  if (!course) {
    return res.status(404).json({ error: "Not Found", message: `Course ${req.params.id} does not exist` });
  }
  const lessons = Array.from(dbStore.lessons.values()).filter((l) => l.course_id === course.course_id).sort((a, b) => a.sequence_no - b.sequence_no);
  const modules = dbStore.getModulesByCourse(course.course_id);
  res.json({ data: { ...course, lessons, modules } });
});
apiRouter.get("/courses/:id/modules", (req, res) => {
  const course = dbStore.courses.get(req.params.id);
  if (!course) {
    return res.status(404).json({ error: "Not Found", message: `Course ${req.params.id} does not exist` });
  }
  const modules = dbStore.getModulesByCourse(course.course_id);
  res.json({ data: modules });
});
apiRouter.get("/modules/:moduleId/videos", (req, res) => {
  const videos = dbStore.getVideosByModule(req.params.moduleId);
  res.json({ data: videos });
});
apiRouter.get("/videos/:videoId", (req, res) => {
  const video = dbStore.getVideo(req.params.videoId);
  if (!video) {
    return res.status(404).json({ error: "Not Found", message: `Video ${req.params.videoId} was not found` });
  }
  res.json({ data: video });
});
apiRouter.put("/videos/:videoId", (req, res) => {
  const { title, youtube_url, duration, description } = req.body;
  const existing = dbStore.getVideo(req.params.videoId);
  if (!existing) {
    return res.status(404).json({ error: "Not Found", message: `Video ${req.params.videoId} was not found` });
  }
  let youtube_video_id = existing.youtube_video_id;
  let embed_url = existing.embed_url;
  let thumbnail_url = existing.thumbnail_url;
  if (youtube_url && typeof youtube_url === "string") {
    const match = youtube_url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i);
    if (match && match[1]) {
      youtube_video_id = match[1];
      embed_url = `https://www.youtube-nocookie.com/embed/${youtube_video_id}`;
      thumbnail_url = `https://img.youtube.com/vi/${youtube_video_id}/hqdefault.jpg`;
    }
  }
  const updated = dbStore.updateVideo(req.params.videoId, {
    title: title ? String(title).trim() : existing.title,
    youtube_url: youtube_url ? String(youtube_url).trim() : existing.youtube_url,
    youtube_video_id,
    embed_url,
    thumbnail_url,
    duration: duration ? String(duration).trim() : existing.duration,
    description: description !== void 0 ? String(description).trim() : existing.description
  });
  res.json({ message: "Video updated successfully", data: updated });
});
apiRouter.post("/videos/:videoId/watch", (req, res) => {
  const video = dbStore.getVideo(req.params.videoId);
  if (!video) {
    return res.status(404).json({ error: "Not Found", message: `Video ${req.params.videoId} not found` });
  }
  const { enrollment_id } = req.body;
  if (!enrollment_id) {
    return res.status(400).json({ error: "Validation Error", message: "enrollment_id is required" });
  }
  const enr = dbStore.enrollments.get(String(enrollment_id));
  if (!enr) {
    return res.status(404).json({ error: "Not Found", message: `Enrollment ${enrollment_id} not found` });
  }
  const actId = `act-${Date.now().toString().slice(-6)}`;
  const now = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  const act = {
    activity_id: actId,
    enrollment_id: enr.enrollment_id,
    lesson_id: video.video_id,
    activity_type: "video_watched",
    activity_date: now,
    completed: false,
    // Critical: Watching/opening does NOT mark as completed
    created_at: now
  };
  dbStore.upsertActivity(act);
  res.json({ message: "Video engagement recorded", data: act });
});
apiRouter.post("/videos/:videoId/complete", (req, res) => {
  const video = dbStore.getVideo(req.params.videoId);
  if (!video) {
    return res.status(404).json({ error: "Not Found", message: `Video ${req.params.videoId} not found` });
  }
  const { enrollment_id } = req.body;
  if (!enrollment_id) {
    return res.status(400).json({ error: "Validation Error", message: "enrollment_id is required" });
  }
  const enr = dbStore.enrollments.get(String(enrollment_id));
  if (!enr) {
    return res.status(404).json({ error: "Not Found", message: `Enrollment ${enrollment_id} not found` });
  }
  const actId = `act-${Date.now().toString().slice(-6)}`;
  const now = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  const act = {
    activity_id: actId,
    enrollment_id: enr.enrollment_id,
    lesson_id: video.video_id,
    activity_type: "video_watched",
    activity_date: now,
    completed: true,
    // Explicitly completed
    created_at: now
  };
  dbStore.upsertActivity(act);
  res.json({ message: "Video marked as completed successfully", data: act });
});
apiRouter.get("/enrollments/:id/video-progress", (req, res) => {
  const enr = dbStore.enrollments.get(req.params.id);
  if (!enr) {
    return res.status(404).json({ error: "Not Found", message: `Enrollment ${req.params.id} not found` });
  }
  const completedActivities = Array.from(dbStore.activities.values()).filter(
    (a) => a.enrollment_id === enr.enrollment_id && a.activity_type === "video_watched" && a.completed
  );
  const completedVideoIds = Array.from(new Set(completedActivities.map((a) => a.lesson_id).filter(Boolean)));
  res.json({
    data: {
      enrollment_id: enr.enrollment_id,
      course_id: enr.course_id,
      completed_video_ids: completedVideoIds,
      total_completed: completedVideoIds.length
    }
  });
});
apiRouter.put("/courses/:id", requireAdmin, (req, res) => {
  const course = dbStore.courses.get(req.params.id);
  if (!course) {
    return res.status(404).json({ error: "Not Found", message: `Course ${req.params.id} does not exist` });
  }
  const { course_name, category, description, is_active } = req.body;
  if (course_name !== void 0) course.course_name = String(course_name).trim();
  if (category !== void 0) course.category = String(category).trim();
  if (description !== void 0) course.description = String(description).trim();
  if (is_active !== void 0) course.is_active = Boolean(is_active);
  course.updated_at = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  dbStore.upsertCourse(course);
  res.json({ message: "Course updated successfully", data: course });
});
apiRouter.patch("/courses/:id/status", requireAdmin, (req, res) => {
  const course = dbStore.courses.get(req.params.id);
  if (!course) {
    return res.status(404).json({ error: "Not Found", message: `Course ${req.params.id} does not exist` });
  }
  const { is_active } = req.body;
  if (is_active === void 0) {
    return res.status(400).json({ error: "Bad Request", message: "is_active boolean required" });
  }
  course.is_active = Boolean(is_active);
  course.updated_at = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  dbStore.upsertCourse(course);
  res.json({ message: `Course ${course.is_active ? "activated" : "deactivated"}`, data: course });
});
apiRouter.get("/courses/:id/lessons", (req, res) => {
  const course = dbStore.courses.get(req.params.id);
  if (!course) {
    return res.status(404).json({ error: "Not Found", message: `Course ${req.params.id} does not exist` });
  }
  const lessons = Array.from(dbStore.lessons.values()).filter((l) => l.course_id === req.params.id).sort((a, b) => a.sequence_no - b.sequence_no);
  res.json({ data: lessons });
});
apiRouter.post("/courses/:id/lessons", requireAdmin, (req, res) => {
  const course = dbStore.courses.get(req.params.id);
  if (!course) {
    return res.status(404).json({ error: "Not Found", message: `Course ${req.params.id} does not exist` });
  }
  const { lesson_name, sequence_no, is_required } = req.body;
  if (!lesson_name || !String(lesson_name).trim()) {
    return res.status(400).json({ error: "Validation Error", message: "lesson_name is required" });
  }
  const existingLessons = Array.from(dbStore.lessons.values()).filter((l) => l.course_id === req.params.id);
  const nextSeq = sequence_no ? Number(sequence_no) : existingLessons.length + 1;
  const lesson_id = `les-${req.params.id.replace("crs-", "")}-${Date.now().toString().slice(-4)}`;
  const newLesson = {
    lesson_id,
    course_id: req.params.id,
    lesson_name: String(lesson_name).trim(),
    sequence_no: nextSeq,
    is_required: is_required !== false,
    created_at: (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19)
  };
  dbStore.upsertLesson(newLesson);
  res.status(201).json({ message: "Lesson added successfully", data: newLesson });
});
apiRouter.put("/lessons/:id", requireAdmin, (req, res) => {
  const lesson = dbStore.lessons.get(req.params.id);
  if (!lesson) {
    return res.status(404).json({ error: "Not Found", message: `Lesson ${req.params.id} does not exist` });
  }
  const { lesson_name, sequence_no, is_required } = req.body;
  if (lesson_name !== void 0) lesson.lesson_name = String(lesson_name).trim();
  if (sequence_no !== void 0) lesson.sequence_no = Number(sequence_no);
  if (is_required !== void 0) lesson.is_required = Boolean(is_required);
  dbStore.upsertLesson(lesson);
  res.json({ message: "Lesson updated successfully", data: lesson });
});
apiRouter.get("/learners", (req, res) => {
  const searchQuery = req.query.search !== void 0 ? sanitizeSearchQuery(req.query.search) : void 0;
  const learners = dbStore.searchLearners(searchQuery);
  const enriched = learners.map((l) => {
    const enrs = Array.from(dbStore.enrollments.values()).filter((e) => e.learner_id === l.learner_id);
    return {
      ...l,
      enrolment_count: enrs.length,
      active_enrolments: enrs.filter((e) => e.status === "enrolled").length,
      completed_enrolments: enrs.filter((e) => e.status === "completed").length
    };
  });
  res.json({ data: enriched });
});
apiRouter.post("/learners", requireAdmin, (req, res) => {
  const { display_name, roll_no } = req.body;
  if (!display_name || !String(display_name).trim()) {
    return res.status(400).json({ error: "Validation Error", message: "display_name is required" });
  }
  if (roll_no) {
    const duplicate = Array.from(dbStore.learners.values()).some((l) => l.roll_no === String(roll_no).trim());
    if (duplicate) {
      return res.status(400).json({ error: "Validation Error", message: `Roll number "${roll_no}" already exists.` });
    }
  }
  const learner_id = `lrn-${Date.now().toString().slice(-5)}`;
  const now = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  const newLearner = {
    learner_id,
    display_name: String(display_name).trim(),
    roll_no: roll_no ? String(roll_no).trim() : void 0,
    created_at: now,
    updated_at: now
  };
  dbStore.upsertLearner(newLearner);
  res.status(201).json({ message: "Learner registered successfully", data: newLearner });
});
apiRouter.get("/learners/:id", (req, res) => {
  const learner = dbStore.learners.get(req.params.id);
  if (!learner) {
    return res.status(404).json({ error: "Not Found", message: `Learner ${req.params.id} not found` });
  }
  const enrs = Array.from(dbStore.enrollments.values()).filter((e) => e.learner_id === learner.learner_id);
  const lessons = Array.from(dbStore.lessons.values());
  const activities = Array.from(dbStore.activities.values());
  const progressList = enrs.map((e) => {
    const course = dbStore.courses.get(e.course_id);
    return calculateEnrolmentProgress(e, lessons, activities, course?.course_name, learner.display_name);
  });
  res.json({ data: { ...learner, enrollments: enrs, progress: progressList } });
});
apiRouter.put("/learners/:id", requireAdmin, (req, res) => {
  const learner = dbStore.learners.get(req.params.id);
  if (!learner) {
    return res.status(404).json({ error: "Not Found", message: `Learner ${req.params.id} not found` });
  }
  const { display_name, roll_no } = req.body;
  if (display_name !== void 0) learner.display_name = String(display_name).trim();
  if (roll_no !== void 0) learner.roll_no = String(roll_no).trim();
  learner.updated_at = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  dbStore.upsertLearner(learner);
  res.json({ message: "Learner updated successfully", data: learner });
});
apiRouter.get("/enrollments", (req, res) => {
  const searchQuery = req.query.search !== void 0 ? sanitizeSearchQuery(req.query.search) : void 0;
  const courseId = req.query.course_id && req.query.course_id !== "All" ? String(req.query.course_id) : void 0;
  const learnerId = req.query.learner_id && req.query.learner_id !== "All" ? String(req.query.learner_id) : void 0;
  const status = req.query.status && req.query.status !== "All" ? String(req.query.status) : void 0;
  const rawEnrollments = dbStore.searchEnrollments(searchQuery, courseId, learnerId, status);
  const lessons = Array.from(dbStore.lessons.values());
  const activities = Array.from(dbStore.activities.values());
  const enriched = rawEnrollments.map((e) => {
    const course = dbStore.courses.get(e.course_id);
    const learner = dbStore.learners.get(e.learner_id);
    const progress = calculateEnrolmentProgress(e, lessons, activities, course?.course_name, learner?.display_name);
    return {
      ...e,
      course_name: course ? course.course_name : e.course_name || e.course_id,
      course_category: course?.category || e.course_category,
      learner_name: learner ? learner.display_name : e.learner_name || e.learner_id,
      roll_no: learner?.roll_no || e.roll_no,
      progress
    };
  });
  res.json({ data: enriched });
});
apiRouter.post("/enrollments", requireAdmin, (req, res) => {
  const { learner_id, course_id, status } = req.body;
  if (!learner_id || !course_id) {
    return res.status(400).json({ error: "Validation Error", message: "learner_id and course_id are required" });
  }
  if (!dbStore.learners.has(learner_id)) {
    return res.status(400).json({ error: "Foreign Key Violation", message: `Learner with ID "${learner_id}" does not exist.` });
  }
  if (!dbStore.courses.has(course_id)) {
    return res.status(400).json({ error: "Foreign Key Violation", message: `Course with ID "${course_id}" does not exist.` });
  }
  const existingActive = Array.from(dbStore.enrollments.values()).find(
    (e) => e.learner_id === learner_id && e.course_id === course_id && e.status === "enrolled"
  );
  if (existingActive) {
    return res.status(409).json({
      error: "Conflict: Duplicate Active Enrolment",
      message: `Learner is already actively enrolled in this course (Enrolment ID: ${existingActive.enrollment_id}). Complete, withdraw, or cancel previous enrolment to re-enrol.`
    });
  }
  const enrollment_id = `enr-${Date.now().toString().slice(-5)}`;
  const now = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  const newEnr = {
    enrollment_id,
    learner_id,
    course_id,
    enrolled_at: now,
    status: status || "enrolled",
    updated_at: now
  };
  dbStore.upsertEnrollment(newEnr);
  res.status(201).json({ message: "Learner enrolled successfully", data: newEnr });
});
apiRouter.patch("/enrollments/:id/status", requireAdmin, (req, res) => {
  const enr = dbStore.enrollments.get(req.params.id);
  if (!enr) {
    return res.status(404).json({ error: "Not Found", message: `Enrolment ${req.params.id} does not exist` });
  }
  const { status } = req.body;
  const validStatuses = ["enrolled", "completed", "withdrawn", "cancelled"];
  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({
      error: "Invalid Status",
      message: `Status must be one of: ${validStatuses.join(", ")}`
    });
  }
  enr.status = status;
  enr.updated_at = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  dbStore.upsertEnrollment(enr);
  res.json({ message: `Enrolment status updated to "${status}"`, data: enr });
});
apiRouter.get("/activities", (req, res) => {
  const searchQuery = req.query.search !== void 0 ? sanitizeSearchQuery(req.query.search) : void 0;
  const courseId = req.query.course_id && req.query.course_id !== "All" ? String(req.query.course_id) : void 0;
  const enrollmentId = req.query.enrollment_id && req.query.enrollment_id !== "All" ? String(req.query.enrollment_id) : void 0;
  const activityType = req.query.activity_type && req.query.activity_type !== "All" ? String(req.query.activity_type) : void 0;
  let activities = dbStore.searchActivities(searchQuery, courseId, enrollmentId, activityType);
  if (req.query.start_date) {
    activities = activities.filter((a) => new Date(a.activity_date) >= new Date(String(req.query.start_date)));
  }
  if (req.query.end_date) {
    activities = activities.filter((a) => new Date(a.activity_date) <= new Date(String(req.query.end_date)));
  }
  res.json({ data: activities });
});
apiRouter.post("/activities", requireAdmin, (req, res) => {
  const { enrollment_id, lesson_id, activity_type, activity_date, completed } = req.body;
  if (!enrollment_id || !activity_type) {
    return res.status(400).json({ error: "Validation Error", message: "enrollment_id and activity_type are required" });
  }
  if (!dbStore.enrollments.has(enrollment_id)) {
    return res.status(400).json({ error: "Foreign Key Violation", message: `Enrolment ID "${enrollment_id}" does not exist.` });
  }
  if (lesson_id && !dbStore.lessons.has(lesson_id)) {
    return res.status(400).json({ error: "Foreign Key Violation", message: `Lesson ID "${lesson_id}" does not exist.` });
  }
  const validTypes = [
    "lesson_opened",
    "lesson_started",
    "lesson_completed",
    "video_watched",
    "resource_accessed"
  ];
  if (!validTypes.includes(activity_type)) {
    return res.status(400).json({ error: "Validation Error", message: `activity_type must be one of: ${validTypes.join(", ")}` });
  }
  const activity_id = `act-${Date.now().toString().slice(-6)}`;
  const now = activity_date ? String(activity_date) : (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19);
  const isCompleted = completed !== void 0 ? Boolean(completed) : activity_type === "lesson_completed";
  const newActivity = {
    activity_id,
    enrollment_id,
    lesson_id: lesson_id || null,
    activity_type,
    activity_date: now,
    completed: isCompleted,
    created_at: (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19)
  };
  dbStore.upsertActivity(newActivity);
  res.status(201).json({ message: "Activity logged successfully", data: newActivity });
});
function parseReferenceDate(refDateStr) {
  if (!refDateStr || refDateStr.trim() === "") {
    return /* @__PURE__ */ new Date();
  }
  const trimmed = refDateStr.trim();
  if (/^\d{2}-\d{2}-\d{4}$/.test(trimmed)) {
    const [d, m, y] = trimmed.split("-").map(Number);
    return new Date(Date.UTC(y, m - 1, d, 23, 59, 59, 999));
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    const [y, m, d] = trimmed.split("-").map(Number);
    return new Date(Date.UTC(y, m - 1, d, 23, 59, 59, 999));
  }
  const parsed = new Date(trimmed);
  return isNaN(parsed.getTime()) ? /* @__PURE__ */ new Date() : parsed;
}
apiRouter.get("/analytics/overview", (req, res) => {
  const courses = Array.from(dbStore.courses.values());
  const learners = Array.from(dbStore.learners.values());
  const enrollments = Array.from(dbStore.enrollments.values());
  const lessons = Array.from(dbStore.lessons.values());
  const activities = Array.from(dbStore.activities.values());
  const performance = calculateCompletionRates(courses, enrollments);
  const totalCourses = courses.length;
  const totalLearners = learners.length;
  const totalEnrolments = enrollments.length;
  const eligibleEnrolments = enrollments.filter((e) => e.status === "enrolled" || e.status === "completed").length;
  const completedEnrolments = enrollments.filter((e) => e.status === "completed").length;
  const overallCompletionRate = eligibleEnrolments > 0 ? Number((completedEnrolments / eligibleEnrolments * 100).toFixed(1)) : 0;
  const refDateParam = req.query.ref_date ? String(req.query.ref_date) : void 0;
  const refDate = parseReferenceDate(refDateParam);
  const learnersMap = new Map(learners.map((l) => [l.learner_id, { display_name: l.display_name, roll_no: l.roll_no }]));
  const inactivity = getInactivityAnalysis(enrollments, activities, dbStore.courses, learnersMap, 14, refDate);
  res.json({
    metrics: {
      total_courses: totalCourses,
      total_learners: totalLearners,
      total_enrolments: totalEnrolments,
      eligible_enrolments: eligibleEnrolments,
      completed_enrolments: completedEnrolments,
      overall_completion_rate: overallCompletionRate,
      active_enrolments: inactivity.active_in_window_count,
      flagged_inactive_enrolments: inactivity.flagged_count
    },
    course_performance: performance,
    denominator_note: "Eligible enrolments = Enrolled + Completed. Excludes Withdrawn and Cancelled."
  });
});
apiRouter.get("/analytics/courses", (req, res) => {
  const courses = Array.from(dbStore.courses.values());
  const enrollments = Array.from(dbStore.enrollments.values());
  const rates = calculateCompletionRates(courses, enrollments);
  res.json({ data: rates });
});
apiRouter.get("/analytics/completion", (req, res) => {
  const courses = Array.from(dbStore.courses.values());
  const enrollments = Array.from(dbStore.enrollments.values());
  const rates = calculateCompletionRates(courses, enrollments);
  const chartData = rates.map((r) => ({
    course_id: r.course_id,
    course_name: r.course_name,
    category: r.category,
    completion_rate_percent: r.completion_rate_percent,
    numerator: r.completed_enrolments,
    denominator: r.eligible_enrolments
  }));
  res.json({ data: chartData });
});
apiRouter.get("/analytics/progress", (req, res) => {
  const enrollments = Array.from(dbStore.enrollments.values()).filter((e) => e.status === "enrolled" || e.status === "completed");
  const lessons = Array.from(dbStore.lessons.values());
  const activities = Array.from(dbStore.activities.values());
  const progressList = enrollments.map((e) => {
    const course = dbStore.courses.get(e.course_id);
    const learner = dbStore.learners.get(e.learner_id);
    return calculateEnrolmentProgress(e, lessons, activities, course?.course_name, learner?.display_name);
  });
  const bandsCount = {
    "0-24%": 0,
    "25-49%": 0,
    "50-74%": 0,
    "75-99%": 0,
    "100%": 0
  };
  progressList.forEach((p) => {
    bandsCount[p.progress_band] = (bandsCount[p.progress_band] || 0) + 1;
  });
  const distribution = Object.entries(bandsCount).map(([band, count]) => ({
    band,
    count,
    percentage: progressList.length > 0 ? Number((count / progressList.length * 100).toFixed(1)) : 0
  }));
  res.json({
    data: {
      distribution,
      total_analyzed: progressList.length,
      individual_progress: progressList
    }
  });
});
apiRouter.get("/analytics/activity/weekly", (req, res) => {
  const activities = Array.from(dbStore.activities.values());
  const weekly = getWeeklyActivitySummary(activities, dbStore.enrollments);
  res.json({ data: weekly });
});
apiRouter.get("/analytics/inactive-enrollments", (req, res) => {
  const thresholdDays = req.query.threshold ? Number(req.query.threshold) : 14;
  const refDateParam = req.query.ref_date ? String(req.query.ref_date) : void 0;
  const refDate = parseReferenceDate(refDateParam);
  const enrollments = Array.from(dbStore.enrollments.values());
  const activities = Array.from(dbStore.activities.values());
  const learners = Array.from(dbStore.learners.values());
  const learnersMap = new Map(learners.map((l) => [l.learner_id, { display_name: l.display_name, roll_no: l.roll_no }]));
  const result = getInactivityAnalysis(enrollments, activities, dbStore.courses, learnersMap, thresholdDays, refDate);
  res.json({ data: result });
});
apiRouter.get("/reports/course-completion", (req, res) => {
  const format = req.query.format;
  const courses = Array.from(dbStore.courses.values());
  const enrollments = Array.from(dbStore.enrollments.values());
  const rates = calculateCompletionRates(courses, enrollments);
  if (format === "csv") {
    const headers = ["Course ID", "Course Name", "Category", "Status", "Total Enrolments", "Eligible Enrolments", "Completed Enrolments", "Completion Rate (%)", "Formula"];
    const rows = rates.map((r) => [
      escapeCsvField(r.course_id),
      escapeCsvField(r.course_name),
      escapeCsvField(r.category),
      escapeCsvField(r.is_active ? "Active" : "Inactive"),
      r.total_enrolments,
      r.eligible_enrolments,
      r.completed_enrolments,
      r.completion_rate_percent,
      escapeCsvField(r.formula)
    ].join(","));
    const csvContent = [
      `# E-Learning Course Completion Report`,
      `# Generated: ${(/* @__PURE__ */ new Date()).toISOString()}`,
      `# Policy: Only enrolled and completed statuses are included in eligible denominator.`,
      headers.join(","),
      ...rows
    ].join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", 'attachment; filename="course_completion_report.csv"');
    return res.send(csvContent);
  }
  res.json({ data: rates });
});
apiRouter.get("/reports/inactive-enrollments", (req, res) => {
  const format = req.query.format;
  const thresholdDays = req.query.threshold ? Number(req.query.threshold) : 14;
  const refDateParam = req.query.ref_date ? String(req.query.ref_date) : void 0;
  const refDate = parseReferenceDate(refDateParam);
  const enrollments = Array.from(dbStore.enrollments.values());
  const activities = Array.from(dbStore.activities.values());
  const learners = Array.from(dbStore.learners.values());
  const learnersMap = new Map(learners.map((l) => [l.learner_id, { display_name: l.display_name, roll_no: l.roll_no }]));
  const result = getInactivityAnalysis(enrollments, activities, dbStore.courses, learnersMap, thresholdDays, refDate);
  if (format === "csv") {
    const headers = ["Enrolment ID", "Learner ID", "Learner Name", "Roll No", "Course ID", "Course Name", "Enrolment Status", "Inactivity Flag", "Days Since Last Activity", "Last Activity Date", "Reason"];
    const rows = result.records.map((r) => [
      escapeCsvField(r.enrollment_id),
      escapeCsvField(r.learner_id),
      escapeCsvField(r.learner_name),
      escapeCsvField(r.roll_no || ""),
      escapeCsvField(r.course_id),
      escapeCsvField(r.course_name),
      escapeCsvField(r.enrollment_status),
      r.is_flagged ? "FLAGGED" : "NORMAL",
      r.days_since_last_activity ?? "N/A",
      escapeCsvField(r.last_recorded_activity || "None"),
      escapeCsvField(r.flag_reason)
    ].join(","));
    const csvContent = [
      `# Inactivity Monitor Report (Threshold: ${thresholdDays} days)`,
      `# Reference Timestamp: ${result.reference_timestamp}`,
      `# Note: Inactivity is a rule-based flag and does not prove absence of learning.`,
      headers.join(","),
      ...rows
    ].join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", 'attachment; filename="inactivity_report.csv"');
    return res.send(csvContent);
  }
  res.json({ data: result });
});
apiRouter.get("/reports/activity", (req, res) => {
  const format = req.query.format;
  const activities = Array.from(dbStore.activities.values());
  if (format === "csv") {
    const headers = ["Activity ID", "Enrolment ID", "Course Name", "Learner Name", "Lesson ID", "Activity Type", "Timestamp", "Completed"];
    const rows = activities.map((a) => {
      const enr = dbStore.enrollments.get(a.enrollment_id);
      const course = enr ? dbStore.courses.get(enr.course_id) : void 0;
      const learner = enr ? dbStore.learners.get(enr.learner_id) : void 0;
      return [
        escapeCsvField(a.activity_id),
        escapeCsvField(a.enrollment_id),
        escapeCsvField(course?.course_name || ""),
        escapeCsvField(learner?.display_name || ""),
        escapeCsvField(a.lesson_id || ""),
        escapeCsvField(a.activity_type),
        escapeCsvField(a.activity_date),
        a.completed ? "YES" : "NO"
      ].join(",");
    });
    const csvContent = [
      `# Learning Activity Log Report`,
      `# Generated: ${(/* @__PURE__ */ new Date()).toISOString()}`,
      headers.join(","),
      ...rows
    ].join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", 'attachment; filename="activity_log.csv"');
    return res.send(csvContent);
  }
  res.json({ data: activities });
});
apiRouter.get("/health", (_req, res) => {
  const health = dbStore.getDatabaseHealth();
  res.status(health.status === "healthy" ? 200 : 503).json({
    status: health.status === "healthy" ? "ok" : "degraded",
    service: "EduPulse Analytics API",
    uptime_seconds: process.uptime(),
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    database: health
  });
});
apiRouter.get("/system/db-status", (_req, res) => {
  const health = dbStore.getDatabaseHealth();
  res.json({ data: health });
});
apiRouter.post("/system/reset", requireAdmin, (_req, res) => {
  dbStore.seed();
  res.json({
    message: "Database successfully re-seeded with reproducible baseline dataset.",
    counts: {
      courses: dbStore.courses.size,
      learners: dbStore.learners.size,
      enrollments: dbStore.enrollments.size,
      lessons: dbStore.lessons.size,
      activities: dbStore.activities.size
    }
  });
});
apiRouter.all("*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `API endpoint ${req.method} ${req.originalUrl || req.url} is not recognized.`,
    statusCode: 404
  });
});

// backend/src/app.ts
var app = express();
app.use(express.json());
app.use((req, _res, next) => {
  if (req.path.startsWith("/api")) {
  }
  next();
});
app.use("/api", apiRouter);
app.all("/api/*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `API endpoint ${req.method} ${req.originalUrl || req.url} was not found.`,
    statusCode: 404
  });
});
app.use((err, _req, res, _next) => {
  const statusCode = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(statusCode).json({
    error: err.error || "Server Error",
    message,
    statusCode
  });
});

// server.ts
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
async function startServer() {
  const app2 = express2();
  let PORT = 3e3;
  if (process.env.DEFAULT_APP_PORT) {
    PORT = parseInt(process.env.DEFAULT_APP_PORT, 10);
  } else if (process.env.NGINX_PORT && process.env.PORT === process.env.NGINX_PORT) {
    PORT = 3e3;
  } else if (process.env.PORT) {
    PORT = parseInt(process.env.PORT, 10);
  }
  const distPath = path.resolve(__dirname, "dist");
  const hasDist = fs.existsSync(distPath);
  const isDev = process.env.NODE_ENV === "development";
  const isProduction = !isDev && (process.env.NODE_ENV === "production" || hasDist || Boolean(process.env.K_SERVICE) && !process.env.DEFAULT_APP_PORT);
  app2.use(app);
  if (isProduction && hasDist) {
    app2.use(express2.static(distPath));
    app2.get("*", (_req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  } else {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== "true",
        watch: process.env.DISABLE_HMR === "true" ? null : {}
      },
      appType: "spa"
    });
    app2.use(vite.middlewares);
  }
  const server = app2.listen(PORT, "0.0.0.0", () => {
    console.log(
      `EduPulse Analytics server running on http://0.0.0.0:${PORT} (${isProduction ? "production" : "development"})`
    );
  });
  server.on("error", (err) => {
    console.error("Server listen error:", err);
    process.exit(1);
  });
  const shutdown = () => {
    console.log("Shutdown signal received: closing HTTP server...");
    server.close(() => {
      console.log("HTTP server closed gracefully.");
      process.exit(0);
    });
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
